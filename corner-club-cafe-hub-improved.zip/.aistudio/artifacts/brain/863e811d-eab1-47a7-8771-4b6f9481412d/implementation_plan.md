# CORNER CLUB — Café Customer Hub & Loyalty Pass

A mobile-first café customer hub and digital loyalty pass experience for **CORNER CLUB**, faithfully matching the reference video's layout, tactile iOS-inspired sheets, and interactive flows—complete with **TablePass** branding, an interactive QR loyalty stamp demo, photo-illustrated digital menus, playable Sudoku, native-style Wi-Fi onboarding, and an anonymous suggestion box.

## User Review & Critical Decisions

> [!IMPORTANT]
> All product preferences from our planning discussion have been locked in and are reflected across the design and architecture below.

- **Confirmed Brand Identity**: Footer, Apple Wallet pass preview, and digital pass attribution use **TablePass** (`Powered by TablePass`).
- **Confirmed Loyalty Stamp Flow**: Tapping **Show my QR code** opens the interactive loyalty pass modal featuring a scannable QR code alongside a **Demo: Add 1 Stamp** control (plus reward redemption at 8/8 stamps and reset) for immediate customer and staff testing.
- **Confirmed Digital Menu Layout**: The slide-up **Our Menus** sheet renders rich menu cards with custom-generated food and beverage photography paired with descriptions, clean dietary metadata, and GBP pricing.
- **Confirmed Theme Support**: Launches in the signature **Vibrant Orange** (`#F5410B`) palette by default, with an optional **Espresso Dark** mode switcher persisted in `localStorage` alongside customer pass details and stamp counts.

---

## 1. Overview & Core Concept

- **What It Does**: Serves as an instant, zero-install NFC/QR table-top hub for café guests. From a single landing screen, visitors can enroll in the 8-stamp coffee loyalty program, generate and preview an Apple Wallet-style pass, browse the café's categorized menu with search, join the guest Wi-Fi via an iOS-style prompt, play a full-featured Sudoku puzzle while waiting for drinks, or send anonymous feedback with optional photos.
- **Target Audience**: Walk-in coffee shop guests scanning a counter QR standee on mobile phones, as well as café baristas testing stamp progression and pass creation.
- **Key Value**: Eliminates friction between physical counter discovery and digital engagement—turning a quick scan into loyalty sign-up, menu browsing, Wi-Fi access, and dwell-time entertainment in seconds.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **Hub Arrival**: Guests land on the vibrant orange hub anchored by a full-bleed latte art hero photograph, the circular white **CORNER CLUB** badge, and five crisp white action cards stacked cleanly within thumb reach.
2. **Loyalty Registration & Pass Builder**:
   - Unregistered guests tap **Start earning rewards** to open the red-orange **Earn Rewards** slide-up sheet.
   - Guests enter their name, email address, optional birthday (Month + Day dropdowns), and optional marketing consent, then tap **Get your loyalty card**.
   - A multi-stage **Building your pass...** reveal animates the orange pass card, header image, `0/8` stamp counter, and QR matrix into view, ending on **Your pass is ready** with **Add to Apple Wallet** (opening an authentic Wallet add-sheet simulation) and **Done**.
   - Returning to the hub transforms the top card into the live stamp tracker (`X / 8 stamps towards a free coffee`), 8 circular stamp dots, and the dark **Show my QR code** button.
3. **Interactive QR & Stamp Demo**: Clicking **Show my QR code** opens the pass card modal where tapping **Demo: Add 1 Stamp** increments the progress dots in real time, celebrates reaching `8 / 8` with a **Redeem Free Coffee** action, and persists state across reloads.
4. **Slide-Up Digital Menu**: Clicking **View Menu** raises a frosted bottom sheet with a drag handle, **Menu | Drinks** mode switch, horizontal category tabs (**Brunch**, **Sweet**, **Sandwiches**, **Seasonal**, **Drinks**), photo-backed menu cards with crisp `·`-separated dietary notes and tabular prices (`£4.00`–`£12.50`), and a sticky bottom **Search menu** bar.
5. **Native iOS Wi-Fi Connect**: Clicking **Connect to Wi-Fi** presents a centered iOS frosted alert (`"Café Hub" Wants to Join Wi-Fi Network "Club Wifi"?`) with **Cancel** and **Join**. Selecting **Join** invokes the `WIFI:S:Club Wifi;T:WPA;P:Password;;` connection sequence, displays an inline **Connecting...** spinner on the card, and transitions to **Connected to Club Wifi** with a quick credentials popover fallback.
6. **Full-Screen Playable Sudoku**: Clicking **Play Sudoku** transitions into a distraction-free 9×9 Sudoku view with Back navigation, tabular `00:00` timer, puzzle Reset, **Easy / Medium / Hard** difficulty switcher, conflict detection, **Notes** pencil mode, **Undo**, **Erase**, **Hint**, and a `1–9` number pad.
7. **Anonymous Suggestion Box**: Clicking **Suggestion Box** opens the red-orange **Honest Feedback** sheet with a dark translucent textarea, working **Attach Photo** file picker with thumbnail preview, and **Send Feedback** confirmation flow.

### Visual Identity & Theme
- **Aesthetic Direction**: Warm, high-energy neighborhood coffee bar meets crisp iOS native sheet ergonomics—clean white cards floating over saturated citrus-tomato orange in light mode, or rich roasted espresso charcoal in dark mode.
- **Color Palette & Mood**:
  - *Vibrant Orange Mode (Default)*: Canvas `#F5410B` (`--bg-hub`), Deep Sheet Accent `#E03406` (`--bg-sheet`), Card Surface `#FFFFFF`, Primary Ink `#171717`, Stamp Red `#E03406`, Dark CTA `#0A0A0A`.
  - *Espresso Dark Mode (Optional Toggle)*: Canvas `#16110E`, Elevated Card `#241C17`, Accent `#FF5722`, Crisp Bone Ink `#F7F3EE`, Muted Stone `#A89F96`.
- **Typography & Hierarchy**:
  - *Display & Brand*: `Plus Jakarta Sans` (700/800) for punchy Café titles and modal headers.
  - *Body & Controls*: `DM Sans` (400/500/600) for crisp legibility on mobile daylight screens.
  - *Timers, Prices & Sudoku Grid*: `JetBrains Mono` with `tabular-nums` for aligned GBP pricing, Sudoku digits, `00:00` timer, and `0/8` stamp readouts.
- **Responsive Viewport Presence**:
  - On mobile (`375px–430px`), fills the portrait screen naturally with `44px+` touch targets and bottom-reachable sheet controls.
  - On desktop/tablet viewports, presents a clean centered café hub stage with subtle ambient backdrop and optional quick-access summary context so desktop visitors never see an isolated narrow strip in an empty void.
- **Interactive Feedback & Motion**: Smooth `180ms–260ms` cubic-bezier sheet slides, springy stamp fill animations, sequenced pass-builder reveal, and `prefers-reduced-motion` support.

---

## 3. Key Product Decisions & Trade-Offs

- **Local Persistence (`localStorage`) vs. Backend Database**:
  - *Chosen Approach*: Persist customer loyalty registration, stamp count, theme preference (`orange` | `dark`), Wi-Fi connection status, Sudoku best/current board state, and submitted feedback count in `localStorage`.
  - *Why*: Matches the client-side café kiosk/pass specification with zero login friction or latency.
  - *Alternatives Considered*: Server-side database or Firebase Auth, which would add unnecessary account walls to a walk-up QR hub.
- **Photo-Rich Menu Cards with Generated Assets**:
  - *Chosen Approach*: Generate cohesive overhead/editorial café photography for the hero latte art and featured menu categories/items so every menu card renders crisp, reliable local imagery with styled SVG fallbacks.
  - *Why*: Eliminates broken external URLs while fulfilling the photo menu card preference with fast load times.
- **Self-Contained Interactive QR & Wallet Simulation**:
  - *Chosen Approach*: Generate a deterministic, crisp QR code SVG directly from the member's pass ID and embed an authentic iOS Wallet Pass preview + **Demo: Add 1 Stamp** interaction rather than relying on broken native `.pkpass` links in web browsers.
  - *Why*: Guarantees every user on iOS, Android, or desktop can test the full loyalty lifecycle immediately.

---

## 4. Technical Architecture & Data Strategy

### Architecture & Component Hierarchy

```text
┌──────────────────────────────────────────────────────────────────────┐
│                       LocalStorage Persistence                       │
│  (loyaltyPass · stamps · theme · wifiJoined · sudokuState · feedback)│
└──────────────────────────────────┬───────────────────────────────────┘
                                   │
                                   ▼
┌──────────────────────────────────────────────────────────────────────┐
│                        CornerClubHub (Root)                          │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │ Hero Latte Banner + Circular Badge + Title + Theme Toggle      │  │
│  └────────────────────────────────────────────────────────────────┘  │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │ LoyaltyStatusCard (Unregistered CTA <-> 8-Stamp Tracker + QR)  │  │
│  └────────────────────────────────────────────────────────────────┘  │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌─────────────┐  │
│  │  View Menu   │ │ Connect WiFi │ │ Play Sudoku  │ │ Suggestion  │  │
│  └──────┬───────┘ └──────┬───────┘ └──────┬───────┘ └──────┬──────┘  │
│         │                │                │                │         │
│         ▼                ▼                ▼                ▼         │
│  ┌────────────┐   ┌────────────┐   ┌────────────┐   ┌────────────┐   │
│  │ MenuSheet  │   │ WifiAlert  │   │ SudokuView │   │ Feedback   │   │
│  │  (Bottom)  │   │  (iOS Box) │   │ (Full-Scr) │   │   Sheet    │   │
│  └────────────┘   └────────────┘   └────────────┘   └────────────┘   │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │ Registration & Wallet Pass Flow (EarnRewards -> PassBuilder -> │  │
│  │ AppleWalletSheet -> Interactive QR & Demo Stamp Modal)         │  │
│  └────────────────────────────────────────────────────────────────┘  │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │ Footer: Instagram Preview/Link + "Powered by TablePass"        │  │
│  └────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────┘
```

### Data Model & State
- **CustomerPass**: `{ id, name, email, birthMonth?, birthDay?, marketingOptIn, stamps (0..8), createdAt }`
- **AppPreferences**: `{ theme: 'orange' | 'dark', wifiStatus: 'idle' | 'connecting' | 'connected' }`
- **MenuItem**: `{ id, group: 'menu' | 'drinks', category: 'Brunch' | 'Sweet' | 'Sandwiches' | 'Seasonal' | 'Drinks', name, description, dietaryNotes, priceGbp, imageSrc }`
- **SudokuSession**: `{ difficulty: 'easy' | 'medium' | 'hard', board, notes, givenMask, solution, history, elapsedSeconds, notesMode, completed }`

### Interactive Component & State Mapping
- **Loyalty Flow**: Form validation on Name + Email -> transitions to animated `PassBuilderModal` -> unlocks `LoyaltyStatusCard` stamp progress and `QRPassModal` with `Demo: Add 1 Stamp`, `Redeem Free Coffee`, and `Add to Apple Wallet` sheet.
- **Digital Menu**: `MenuSheet` filters items reactively by `group` (`Menu` / `Drinks`), category tab, and bottom search input query with empty-search state handling.
- **Wi-Fi Connect**: `WifiAlertModal` confirms joining `"Club Wifi"`, dispatches `WIFI:S:Club Wifi;T:WPA;P:Password;;` link/copy action, animates `Connecting...` for ~1.4s, and updates the hub row to `Connected to Club Wifi`.
- **Sudoku Engine**: Deterministic puzzle generator/presets per difficulty with valid solution matrix, pencil-mark toggle, multi-step undo stack, conflict highlight, hint filler, and persistent timer.
- **Suggestion Box**: Validates non-empty message, supports local image file attachment preview via `FileReader`, simulates anonymous submission with delay notice, and resets cleanly.
