import { SudokuDifficulty, SudokuState } from '../types';

function shuffleArray<T>(items: T[]): T[] {
  const arr = [...items];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function isValidPlacement(board: number[], index: number, value: number): boolean {
  const row = Math.floor(index / 9);
  const col = index % 9;

  for (let c = 0; c < 9; c++) {
    if (board[row * 9 + c] === value) return false;
  }
  for (let r = 0; r < 9; r++) {
    if (board[r * 9 + col] === value) return false;
  }

  const boxRow = Math.floor(row / 3) * 3;
  const boxCol = Math.floor(col / 3) * 3;
  for (let r = 0; r < 3; r++) {
    for (let c = 0; c < 3; c++) {
      if (board[(boxRow + r) * 9 + (boxCol + c)] === value) return false;
    }
  }
  return true;
}

function fillBoard(board: number[], index = 0): boolean {
  if (index === 81) return true;
  if (board[index] !== 0) return fillBoard(board, index + 1);

  const candidates = shuffleArray([1, 2, 3, 4, 5, 6, 7, 8, 9]);
  for (const num of candidates) {
    if (isValidPlacement(board, index, num)) {
      board[index] = num;
      if (fillBoard(board, index + 1)) return true;
      board[index] = 0;
    }
  }
  return false;
}

export function createSudokuPuzzle(difficulty: SudokuDifficulty): SudokuState {
  const solution = Array(81).fill(0);
  fillBoard(solution);

  const cluesCount =
    difficulty === 'easy' ? 42 : difficulty === 'medium' ? 33 : 25;

  const indices = shuffleArray(Array.from({ length: 81 }, (_, i) => i));
  const board = [...solution];
  const cellsToRemove = 81 - cluesCount;

  for (let i = 0; i < cellsToRemove; i++) {
    board[indices[i]] = 0;
  }

  const givenMask = board.map((v) => v !== 0);
  const notes = Array.from({ length: 81 }, () => [] as number[]);

  return {
    difficulty,
    board,
    solution,
    givenMask,
    notes,
    history: [],
    elapsedSeconds: 0,
    notesMode: false,
    completed: false,
  };
}

export function isCellConflicting(board: number[], index: number): boolean {
  const value = board[index];
  if (value === 0) return false;

  const row = Math.floor(index / 9);
  const col = index % 9;

  for (let c = 0; c < 9; c++) {
    const idx = row * 9 + c;
    if (idx !== index && board[idx] === value) return true;
  }
  for (let r = 0; r < 9; r++) {
    const idx = r * 9 + col;
    if (idx !== index && board[idx] === value) return true;
  }
  const boxRow = Math.floor(row / 3) * 3;
  const boxCol = Math.floor(col / 3) * 3;
  for (let r = 0; r < 3; r++) {
    for (let c = 0; c < 3; c++) {
      const idx = (boxRow + r) * 9 + (boxCol + c);
      if (idx !== index && board[idx] === value) return true;
    }
  }
  return false;
}

export function isBoardSolved(board: number[], solution: number[]): boolean {
  for (let i = 0; i < 81; i++) {
    if (board[i] === 0 || board[i] !== solution[i]) return false;
  }
  return true;
}

export function formatTimer(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}
