export type ThemeMode = 'orange' | 'dark';

export type WifiStatus = 'idle' | 'connecting' | 'connected';

export interface CustomerPass {
  id: string;
  name: string;
  email: string;
  birthMonth: string;
  birthDay: string;
  marketingOptIn: boolean;
  stamps: number;
  redeemedCount: number;
  walletAdded: boolean;
  createdAt: string;
}

export type MenuCategory = 'Brunch' | 'Sweet' | 'Sandwiches' | 'Seasonal' | 'Drinks';

export type MenuGroup = 'menu' | 'drinks';

export interface MenuItem {
  id: string;
  group: MenuGroup;
  category: MenuCategory;
  name: string;
  description: string;
  dietary?: string;
  allergens?: string;
  price: number;
  imageSrc: string;
}

export type SudokuDifficulty = 'easy' | 'medium' | 'hard';

export interface SudokuHistoryEntry {
  board: number[];
  notes: number[][];
}

export interface SudokuState {
  difficulty: SudokuDifficulty;
  board: number[];
  solution: number[];
  givenMask: boolean[];
  notes: number[][];
  history: SudokuHistoryEntry[];
  elapsedSeconds: number;
  notesMode: boolean;
  completed: boolean;
}

export interface FeedbackEntry {
  id: string;
  message: string;
  hasPhoto: boolean;
  photoDataUrl?: string;
  createdAt: string;
}
