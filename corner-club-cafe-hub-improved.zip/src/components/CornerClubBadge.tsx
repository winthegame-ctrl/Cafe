import React from 'react';

interface CornerClubBadgeProps {
  size?: 'sm' | 'md' | 'lg';
  variant?: 'circle' | 'square';
  className?: string;
}

export const CornerClubBadge: React.FC<CornerClubBadgeProps> = ({
  size = 'lg',
  variant = 'circle',
  className = '',
}) => {
  if (variant === 'square') {
    return (
      <div
        className={`flex items-center justify-center rounded-md bg-white text-[#E03406] font-display font-extrabold tracking-tight leading-none select-none shadow-sm ${
          size === 'sm' ? 'w-7 h-7 text-[6px]' : 'w-9 h-9 text-[7.5px]'
        } ${className}`}
      >
        <div className="text-center uppercase">
          <div>CORNER</div>
          <div>CLUB</div>
        </div>
      </div>
    );
  }

  const sizeClasses =
    size === 'lg'
      ? 'w-[76px] h-[76px] text-[11px] ring-4 ring-white/25'
      : size === 'md'
        ? 'w-14 h-14 text-[9px] ring-2 ring-white/25'
        : 'w-10 h-10 text-[7px] ring-2 ring-white/20';

  return (
    <div
      className={`rounded-full bg-white text-[#E03406] flex flex-col items-center justify-center shadow-lg select-none shrink-0 ${sizeClasses} ${className}`}
    >
      <span className="font-display font-extrabold tracking-tighter leading-[0.95] uppercase">
        CORNER
      </span>
      <span className="font-display font-extrabold tracking-tighter leading-[0.95] uppercase">
        CLUB
      </span>
    </div>
  );
};
