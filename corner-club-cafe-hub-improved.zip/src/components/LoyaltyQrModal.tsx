import React, { useState } from 'react';
import { Coffee, Gift, RotateCcw, Wallet, X, ShieldCheck } from 'lucide-react';
import { CustomerPass } from '../types';
import { WalletPassCard } from './RegistrationPassModal';

interface LoyaltyQrModalProps {
  isOpen: boolean;
  pass: CustomerPass | null;
  onClose: () => void;
  onRedeemFreeCoffee: () => void;
  onResetPass: () => void;
}

export const LoyaltyQrModal: React.FC<LoyaltyQrModalProps> = ({
  isOpen,
  pass,
  onClose,
  onRedeemFreeCoffee,
  onResetPass,
}) => {
  const [showWalletPrompt, setShowWalletPrompt] = useState(false);
  const [justRedeemed, setJustRedeemed] = useState(false);

  if (!isOpen || !pass) return null;

  const isRewardReady = pass.stamps >= 8;

  const handleRedeem = () => {
    onRedeemFreeCoffee();
    setJustRedeemed(true);
    window.setTimeout(() => setJustRedeemed(false), 2600);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md bg-[#F7F6F5] dark:bg-[#1B1512] text-neutral-900 dark:text-[#F7F3EE] rounded-t-[28px] sm:rounded-[28px] shadow-2xl overflow-hidden animate-sheet-up max-h-[94vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {showWalletPrompt ? (
          <div>
            <div className="flex items-center justify-between px-4 py-3.5 border-b border-neutral-200 dark:border-white/10">
              <button
                type="button"
                onClick={() => setShowWalletPrompt(false)}
                aria-label="Cancel Wallet preview"
                className="w-9 h-9 rounded-full bg-neutral-200/80 dark:bg-white/10 flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
              <span className="font-semibold text-[15px]">Loyalty card preview</span>
              <button
                type="button"
                onClick={() => setShowWalletPrompt(false)}
                className="px-4 py-1.5 rounded-full bg-[#E03406] text-white text-sm font-semibold active:scale-95 transition-transform"
              >
                Close
              </button>
            </div>
            <div className="p-5">
              <WalletPassCard pass={pass} phase={4} />
            </div>
          </div>
        ) : (
          <div className="px-5 pt-3 pb-6 overflow-y-auto">
            <div className="flex items-center justify-between mb-3">
              <div className="w-9" />
              <div className="w-10 h-1 rounded-full bg-neutral-300 dark:bg-white/20" />
              <button
                type="button"
                onClick={onClose}
                aria-label="Close loyalty pass"
                className="w-9 h-9 rounded-full flex items-center justify-center text-neutral-500 hover:bg-neutral-200/70 dark:hover:bg-white/10 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="text-center mb-4">
              <h2 className="font-display text-lg font-bold tracking-tight">
                Show to Barista at Till
              </h2>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                Member ID: <span className="font-mono-tabular font-semibold">{pass.id}</span>
                {pass.redeemedCount > 0 && ` · ${pass.redeemedCount} free coffee redeemed`}
              </p>
            </div>

            <WalletPassCard pass={pass} phase={4} />

            {justRedeemed && (
              <div className="mt-4 px-4 py-3 rounded-2xl bg-emerald-600 text-white text-sm font-semibold flex items-center justify-center gap-2 animate-stamp-pop">
                <Coffee className="w-4 h-4" />
                <span>Free coffee redeemed! Stamp card reset to 0 / 8.</span>
              </div>
            )}

            <div className="mt-4 space-y-2.5">
              {isRewardReady ? (
                <button
                  type="button"
                  onClick={handleRedeem}
                  className="w-full min-h-[48px] rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-display font-bold text-[15px] flex items-center justify-center gap-2 shadow-md active:scale-[0.98] transition-all cursor-pointer"
                >
                  <Gift className="w-4 h-4" />
                  <span>Redeem Free Coffee (8 / 8 Ready!)</span>
                </button>
              ) : (
                <div className="w-full rounded-2xl border border-orange-200 bg-orange-50 px-4 py-3.5 dark:border-orange-900/60 dark:bg-orange-950/30">
                  <div className="flex items-start gap-2.5">
                    <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-[#E03406]" />
                    <div>
                      <p className="text-sm font-bold text-neutral-900 dark:text-white">
                        Show this QR code to your barista
                      </p>
                      <p className="mt-1 text-xs leading-relaxed text-neutral-600 dark:text-neutral-300">
                        Show your member QR to the barista. Live stamp updates require the café's loyalty system to be connected.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => setShowWalletPrompt(true)}
                  className="min-h-[44px] px-3 rounded-xl bg-white dark:bg-white/10 border border-neutral-200 dark:border-white/10 text-xs font-semibold flex items-center justify-center gap-1.5 hover:bg-neutral-50 dark:hover:bg-white/15 active:scale-[0.98] transition-all cursor-pointer"
                >
                  <>
                    <Wallet className="w-3.5 h-3.5" />
                    <span>Preview loyalty pass</span>
                  </>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    onResetPass();
                    onClose();
                  }}
                  className="min-h-[44px] px-3 rounded-xl bg-white dark:bg-white/10 border border-neutral-200 dark:border-white/10 text-xs font-semibold text-neutral-600 dark:text-neutral-300 flex items-center justify-center gap-1.5 hover:bg-neutral-50 dark:hover:bg-white/15 active:scale-[0.98] transition-all cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset Card</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
