import React, { useMemo, useState } from 'react';
import { Coffee, Search, X } from 'lucide-react';
import { MENU_CATEGORIES, MENU_ITEMS, formatPriceGbp } from '../data/menuData';
import { MenuCategory, MenuGroup } from '../types';

interface MenuSheetProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MenuSheet: React.FC<MenuSheetProps> = ({ isOpen, onClose }) => {
  const [activeGroup, setActiveGroup] = useState<MenuGroup>('menu');
  const [activeCategory, setActiveCategory] = useState<MenuCategory>('Brunch');
  const [searchQuery, setSearchQuery] = useState('');
  const [dietaryFilter, setDietaryFilter] = useState<'all' | 'vegetarian' | 'vegan'>('all');
  const [failedImages, setFailedImages] = useState<Record<string, boolean>>({});

  const visibleItems = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return MENU_ITEMS.filter((item) => {
      const matchesSearch = !q || (
        item.name.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q) ||
        (item.dietary || '').toLowerCase().includes(q) ||
        (item.allergens || '').toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q)
      );
      const matchesSection = q || (activeGroup === 'drinks'
        ? item.category === 'Drinks'
        : item.category === activeCategory);
      const dietary = (item.dietary || '').toLowerCase();
      const matchesDiet = dietaryFilter === 'all' ||
        (dietaryFilter === 'vegan' ? dietary.includes('vegan') : dietary.includes('veg'));
      return Boolean(matchesSearch && matchesSection && matchesDiet);
    });
  }, [activeCategory, activeGroup, searchQuery, dietaryFilter]);

  if (!isOpen) return null;

  const handleGroupSwitch = (group: MenuGroup) => {
    setActiveGroup(group);
    if (group === 'drinks') {
      setActiveCategory('Drinks');
    } else if (activeCategory === 'Drinks') {
      setActiveCategory('Brunch');
    }
  };

  const handleCategoryClick = (category: MenuCategory) => {
    setActiveCategory(category);
    setActiveGroup(category === 'Drinks' ? 'drinks' : 'menu');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/55 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md h-[88vh] sm:h-[82vh] bg-white dark:bg-[#1B1512] text-neutral-900 dark:text-[#F7F3EE] rounded-t-[28px] sm:rounded-[28px] shadow-2xl flex flex-col overflow-hidden animate-sheet-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Pull handle & top header */}
        <div className="px-5 pt-3 pb-3 border-b border-neutral-100 dark:border-white/10 shrink-0">
          <div className="flex justify-center mb-2">
            <div className="w-10 h-1 rounded-full bg-neutral-300 dark:bg-white/20" />
          </div>

          <div className="flex items-center justify-between">
            <h2 className="font-display text-xl font-bold tracking-tight">Our Menus</h2>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close menu"
              className="w-9 h-9 rounded-full flex items-center justify-center text-neutral-500 hover:bg-neutral-100 dark:hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Menu | Drinks segmented control */}
          <div className="mt-3 inline-flex items-center p-1 rounded-xl bg-neutral-100 dark:bg-white/10">
            <button
              type="button"
              onClick={() => handleGroupSwitch('menu')}
              className={`px-4 py-1.5 text-[13px] font-semibold rounded-lg transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                activeGroup === 'menu'
                  ? 'bg-[#E03406] text-white shadow-sm'
                  : 'text-neutral-600 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white'
              }`}
            >
              Menu
            </button>
            <button
              type="button"
              onClick={() => handleGroupSwitch('drinks')}
              className={`px-4 py-1.5 text-[13px] font-semibold rounded-lg transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                activeGroup === 'drinks'
                  ? 'bg-[#E03406] text-white shadow-sm'
                  : 'text-neutral-600 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white'
              }`}
            >
              Drinks
            </button>
          </div>

          {/* Horizontal category tabs */}
          <div className="mt-3 flex items-center gap-2 overflow-x-auto no-scrollbar pb-0.5">
            {MENU_CATEGORIES.map((category) => {
              const isActive =
                searchQuery.trim() === '' && activeCategory === category;
              return (
                <button
                  key={category}
                  type="button"
                  onClick={() => handleCategoryClick(category)}
                  className={`px-3.5 py-2 text-xs font-semibold rounded-xl border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    isActive
                      ? 'bg-[#E03406] text-white border-[#E03406]'
                      : 'bg-neutral-50 dark:bg-white/5 text-neutral-700 dark:text-neutral-300 border-neutral-200 dark:border-white/10 hover:bg-neutral-100 dark:hover:bg-white/10'
                  }`}
                >
                  {category}
                </button>
              );
            })}
          </div>

          <div className="mt-3 flex items-center gap-2 overflow-x-auto no-scrollbar">
            {([
              ['all', 'All items'],
              ['vegetarian', 'Vegetarian'],
              ['vegan', 'Vegan'],
            ] as const).map(([value, label]) => (
              <button
                key={value}
                type="button"
                onClick={() => setDietaryFilter(value)}
                aria-pressed={dietaryFilter === value}
                className={`shrink-0 rounded-full px-3 py-1.5 text-[11px] font-bold border transition-colors ${
                  dietaryFilter === value
                    ? 'border-[#E03406] bg-[#FFF0E9] text-[#B8320C] dark:bg-orange-950/40 dark:text-orange-200'
                    : 'border-neutral-200 bg-white text-neutral-600 dark:border-white/10 dark:bg-white/5 dark:text-neutral-300'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Scrollable menu items */}
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
          <div className="flex items-baseline justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-400 dark:text-neutral-500">
              {searchQuery.trim()
                ? `Search results (${visibleItems.length})`
                : activeCategory}
            </h3>
            <span className="text-xs text-neutral-400 dark:text-neutral-500 font-mono-tabular">
              {visibleItems.length} {visibleItems.length === 1 ? 'item' : 'items'}
            </span>
          </div>

          {visibleItems.length === 0 ? (
            <div className="py-14 px-5 text-left space-y-2 rounded-2xl bg-neutral-50 dark:bg-white/5">
              <p className="text-sm font-semibold text-neutral-800 dark:text-neutral-200">
                {searchQuery.trim()
                  ? `No menu items match “${searchQuery}”.`
                  : `No ${dietaryFilter === 'vegan' ? 'vegan' : 'vegetarian'} items in this section yet.`}
              </p>
              <button
                type="button"
                onClick={() => { setSearchQuery(''); setDietaryFilter('all'); }}
                className="text-xs font-semibold text-[#E03406] hover:underline"
              >
                Clear filters
              </button>
            </div>
          ) : (
            <div className="space-y-3.5">
              {visibleItems.map((item) => {
                const imgBroken = failedImages[item.id];
                return (
                  <article
                    key={item.id}
                    className="flex gap-3.5 pb-3.5 border-b border-neutral-100 dark:border-white/10 last:border-b-0"
                  >
                    <div className="w-[88px] h-[88px] rounded-[18px] overflow-hidden bg-neutral-100 dark:bg-white/5 shrink-0">
                      {!imgBroken ? (
                        <img
                          src={item.imageSrc}
                          alt={item.name}
                          loading="lazy"
                          referrerPolicy="no-referrer"
                          onError={() =>
                            setFailedImages((prev) => ({ ...prev, [item.id]: true }))
                          }
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full bg-[#FFF0E9] dark:bg-orange-950/40 flex items-center justify-center text-[#E03406]">
                          <Coffee className="w-6 h-6" />
                        </div>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <h4 className="font-display font-bold text-[15px] leading-snug text-neutral-900 dark:text-white">
                          {item.name}
                        </h4>
                        <span className="font-mono-tabular font-semibold text-[15px] text-neutral-900 dark:text-white shrink-0">
                          {formatPriceGbp(item.price)}
                        </span>
                      </div>

                      <p className="mt-1.5 text-[13px] leading-[1.55] text-neutral-600 dark:text-neutral-300">
                        {item.description}
                      </p>

                      {(item.dietary || item.allergens) && (
                        <div className="mt-1.5 text-xs text-neutral-400 dark:text-neutral-500 flex flex-wrap items-center gap-x-1.5">
                          {item.dietary && (
                            <span className="font-medium text-neutral-600 dark:text-neutral-400">
                              {item.dietary}
                            </span>
                          )}
                          {item.dietary && item.allergens && (
                            <span aria-hidden="true">·</span>
                          )}
                          {item.allergens && <span>{item.allergens}</span>}
                        </div>
                      )}
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </div>

        {/* Sticky bottom Search bar */}
        <div className="p-4 border-t border-neutral-100 dark:border-white/10 bg-white/95 dark:bg-[#1B1512]/95 backdrop-blur-md shrink-0">
          <div className="relative flex items-center">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 pointer-events-none" />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search food, drinks or ingredients"
              aria-label="Search menu"
              className="w-full min-h-[44px] pl-10 pr-10 rounded-2xl bg-neutral-100 dark:bg-white/10 text-sm text-neutral-900 dark:text-white placeholder:text-neutral-400 outline-none focus:ring-2 focus:ring-[#E03406]"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                aria-label="Clear search"
                className="w-8 h-8 rounded-full flex items-center justify-center text-neutral-400 hover:text-neutral-700 dark:hover:text-white absolute right-1.5"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
