import React, { useEffect, useState } from 'react';
import {
  ChevronLeft,
  Eraser,
  Lightbulb,
  Pencil,
  RotateCw,
  Trophy,
  Undo2,
} from 'lucide-react';
import { SudokuDifficulty, SudokuState } from '../types';
import {
  createSudokuPuzzle,
  formatTimer,
  isBoardSolved,
  isCellConflicting,
} from '../utils/sudoku';

interface SudokuScreenProps {
  isOpen: boolean;
  sudoku: SudokuState;
  onUpdateSudoku: React.Dispatch<React.SetStateAction<SudokuState>>;
  onBack: () => void;
}

export const SudokuScreen: React.FC<SudokuScreenProps> = ({
  isOpen,
  sudoku,
  onUpdateSudoku,
  onBack,
}) => {
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);

  // Timer tick while Sudoku screen is open and not completed
  useEffect(() => {
    if (!isOpen || sudoku.completed) return;
    const interval = window.setInterval(() => {
      onUpdateSudoku((prev) => {
        if (prev.completed) return prev;
        return { ...prev, elapsedSeconds: prev.elapsedSeconds + 1 };
      });
    }, 1000);
    return () => window.clearInterval(interval);
  }, [isOpen, sudoku.completed, onUpdateSudoku]);

  // Keyboard support for desktop play
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onBack();
        return;
      }
      if (selectedIdx === null) return;
      if (e.key >= '1' && e.key <= '9') {
        handleNumberInput(Number(e.key));
      } else if (e.key === 'Backspace' || e.key === 'Delete') {
        handleErase();
      } else if (e.key === 'ArrowRight') {
        setSelectedIdx((idx) => (idx === null ? 0 : (idx + 1) % 81));
      } else if (e.key === 'ArrowLeft') {
        setSelectedIdx((idx) => (idx === null ? 0 : (idx + 80) % 81));
      } else if (e.key === 'ArrowDown') {
        setSelectedIdx((idx) => (idx === null ? 0 : (idx + 9) % 81));
      } else if (e.key === 'ArrowUp') {
        setSelectedIdx((idx) => (idx === null ? 0 : (idx + 72) % 81));
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  });

  if (!isOpen) return null;

  const selectedValue = selectedIdx !== null ? sudoku.board[selectedIdx] : 0;
  const selectedRow = selectedIdx !== null ? Math.floor(selectedIdx / 9) : -1;
  const selectedCol = selectedIdx !== null ? selectedIdx % 9 : -1;
  const selectedBox =
    selectedIdx !== null
      ? Math.floor(selectedRow / 3) * 3 + Math.floor(selectedCol / 3)
      : -1;

  const handleDifficultyChange = (difficulty: SudokuDifficulty) => {
    setSelectedIdx(null);
    onUpdateSudoku(createSudokuPuzzle(difficulty));
  };

  const handleReset = () => {
    setSelectedIdx(null);
    onUpdateSudoku(createSudokuPuzzle(sudoku.difficulty));
  };

  const handleNumberInput = (num: number) => {
    if (selectedIdx === null || sudoku.completed) return;
    if (sudoku.givenMask[selectedIdx]) return;

    onUpdateSudoku((prev) => {
      const historyEntry = {
        board: [...prev.board],
        notes: prev.notes.map((arr) => [...arr]),
      };

      if (prev.notesMode) {
        if (prev.board[selectedIdx] !== 0) return prev;
        const nextNotes = prev.notes.map((arr) => [...arr]);
        const current = nextNotes[selectedIdx];
        if (current.includes(num)) {
          nextNotes[selectedIdx] = current.filter((n) => n !== num);
        } else {
          nextNotes[selectedIdx] = [...current, num].sort((a, b) => a - b);
        }
        return {
          ...prev,
          notes: nextNotes,
          history: [...prev.history.slice(-29), historyEntry],
        };
      }

      const nextBoard = [...prev.board];
      nextBoard[selectedIdx] = nextBoard[selectedIdx] === num ? 0 : num;
      const nextNotes = prev.notes.map((arr, idx) =>
        idx === selectedIdx ? [] : [...arr]
      );
      const completed = isBoardSolved(nextBoard, prev.solution);

      return {
        ...prev,
        board: nextBoard,
        notes: nextNotes,
        history: [...prev.history.slice(-29), historyEntry],
        completed,
      };
    });
  };

  const handleUndo = () => {
    if (sudoku.history.length === 0 || sudoku.completed) return;
    onUpdateSudoku((prev) => {
      const last = prev.history[prev.history.length - 1];
      return {
        ...prev,
        board: last.board,
        notes: last.notes,
        history: prev.history.slice(0, -1),
      };
    });
  };

  const handleErase = () => {
    if (selectedIdx === null || sudoku.completed) return;
    if (sudoku.givenMask[selectedIdx]) return;
    if (sudoku.board[selectedIdx] === 0 && sudoku.notes[selectedIdx].length === 0) return;

    onUpdateSudoku((prev) => {
      const historyEntry = {
        board: [...prev.board],
        notes: prev.notes.map((arr) => [...arr]),
      };
      const nextBoard = [...prev.board];
      nextBoard[selectedIdx] = 0;
      const nextNotes = prev.notes.map((arr, idx) =>
        idx === selectedIdx ? [] : [...arr]
      );
      return {
        ...prev,
        board: nextBoard,
        notes: nextNotes,
        history: [...prev.history.slice(-29), historyEntry],
      };
    });
  };

  const handleHint = () => {
    if (sudoku.completed) return;
    const targetIdx =
      selectedIdx !== null &&
      !sudoku.givenMask[selectedIdx] &&
      sudoku.board[selectedIdx] !== sudoku.solution[selectedIdx]
        ? selectedIdx
        : sudoku.board.findIndex((val, idx) => val !== sudoku.solution[idx]);

    if (targetIdx === -1) return;

    setSelectedIdx(targetIdx);
    onUpdateSudoku((prev) => {
      const historyEntry = {
        board: [...prev.board],
        notes: prev.notes.map((arr) => [...arr]),
      };
      const nextBoard = [...prev.board];
      nextBoard[targetIdx] = prev.solution[targetIdx];
      const nextNotes = prev.notes.map((arr, idx) =>
        idx === targetIdx ? [] : [...arr]
      );
      const completed = isBoardSolved(nextBoard, prev.solution);
      return {
        ...prev,
        board: nextBoard,
        notes: nextNotes,
        history: [...prev.history.slice(-29), historyEntry],
        completed,
      };
    });
  };

  const toggleNotesMode = () => {
    onUpdateSudoku((prev) => ({ ...prev, notesMode: !prev.notesMode }));
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#F4F4F5] dark:bg-[#14100E] text-neutral-900 dark:text-[#F7F3EE] flex flex-col items-center justify-between overflow-y-auto">
      <div className="w-full max-w-md flex flex-col min-h-full px-4 pt-3 pb-6 justify-between">
        {/* Top bar */}
        <header className="flex items-center justify-between py-2">
          <button
            type="button"
            onClick={onBack}
            aria-label="Back to hub"
            className="w-11 h-11 rounded-full bg-white dark:bg-[#231B16] shadow-sm border border-neutral-200/70 dark:border-white/10 flex items-center justify-center active:scale-95 transition-transform cursor-pointer"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2">
            <span className="px-4 py-1.5 rounded-full bg-white dark:bg-[#231B16] border border-neutral-200/70 dark:border-white/10 font-mono-tabular text-sm font-semibold shadow-sm">
              {formatTimer(sudoku.elapsedSeconds)}
            </span>
            <button
              type="button"
              onClick={handleReset}
              aria-label="New puzzle"
              className="w-11 h-11 rounded-full bg-white dark:bg-[#231B16] shadow-sm border border-neutral-200/70 dark:border-white/10 flex items-center justify-center active:scale-95 transition-transform cursor-pointer"
            >
              <RotateCw className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* Difficulty Switcher */}
        <div className="grid grid-cols-3 gap-1.5 p-1 rounded-2xl bg-neutral-200/80 dark:bg-white/10 my-2">
          {(['easy', 'medium', 'hard'] as SudokuDifficulty[]).map((diff) => {
            const active = sudoku.difficulty === diff;
            return (
              <button
                key={diff}
                type="button"
                onClick={() => handleDifficultyChange(diff)}
                className={`min-h-[38px] rounded-xl text-xs font-semibold capitalize transition-all cursor-pointer ${
                  active
                    ? 'bg-white dark:bg-[#2A201A] text-neutral-950 dark:text-white shadow-sm'
                    : 'text-neutral-600 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white'
                }`}
              >
                {diff}
              </button>
            );
          })}
        </div>

        {/* Completion Banner */}
        {sudoku.completed && (
          <div className="mb-2 px-4 py-3 rounded-2xl bg-emerald-600 text-white flex items-center justify-between shadow-md animate-stamp-pop">
            <div className="flex items-center gap-2.5">
              <Trophy className="w-5 h-5 shrink-0" />
              <div>
                <div className="font-display font-bold text-sm">Puzzle Solved!</div>
                <div className="text-xs text-white/90 font-mono-tabular">
                  Time: {formatTimer(sudoku.elapsedSeconds)} · {sudoku.difficulty}
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={handleReset}
              className="px-3 py-1.5 rounded-xl bg-white text-emerald-700 text-xs font-bold cursor-pointer"
            >
              Play Again
            </button>
          </div>
        )}

        {/* 9x9 Grid */}
        <div className="my-auto py-2">
          <div className="aspect-square w-full bg-white dark:bg-[#1E1713] rounded-xl overflow-hidden border-2 border-neutral-900 dark:border-neutral-400 shadow-md grid grid-cols-9 grid-rows-9">
            {sudoku.board.map((val, idx) => {
              const row = Math.floor(idx / 9);
              const col = idx % 9;
              const box = Math.floor(row / 3) * 3 + Math.floor(col / 3);
              const isGiven = sudoku.givenMask[idx];
              const isSelected = selectedIdx === idx;
              const isPeer =
                selectedIdx !== null &&
                !isSelected &&
                (row === selectedRow || col === selectedCol || box === selectedBox);
              const isMatchingDigit =
                selectedValue !== 0 && val === selectedValue && !isSelected;
              const hasConflict =
                val !== 0 &&
                !isGiven &&
                (isCellConflicting(sudoku.board, idx) || val !== sudoku.solution[idx]);

              const borderRight =
                col === 2 || col === 5
                  ? 'border-r-2 border-r-neutral-900 dark:border-r-neutral-400'
                  : col === 8
                    ? ''
                    : 'border-r border-r-neutral-200 dark:border-r-white/10';
              const borderBottom =
                row === 2 || row === 5
                  ? 'border-b-2 border-b-neutral-900 dark:border-b-neutral-400'
                  : row === 8
                    ? ''
                    : 'border-b border-b-neutral-200 dark:border-b-white/10';

              let bgClass = 'bg-transparent';
              if (isSelected) {
                bgClass = 'bg-orange-100 dark:bg-orange-950/50';
              } else if (hasConflict) {
                bgClass = 'bg-red-100 dark:bg-red-950/60';
              } else if (isMatchingDigit) {
                bgClass = 'bg-orange-50 dark:bg-orange-950/30';
              } else if (isPeer) {
                bgClass = 'bg-neutral-100 dark:bg-white/5';
              }

              const textColor = isGiven
                ? 'text-neutral-950 dark:text-white font-semibold'
                : hasConflict
                  ? 'text-red-600 dark:text-red-400 font-semibold'
                  : 'text-[#E03406] dark:text-orange-300 font-semibold';

              return (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setSelectedIdx(idx)}
                  aria-label={`Row ${row + 1} Column ${col + 1}${val ? `, value ${val}` : ', empty'}`}
                  className={`relative flex items-center justify-center select-none transition-colors cursor-pointer ${borderRight} ${borderBottom} ${bgClass}`}
                >
                  {val !== 0 ? (
                    <span className={`font-mono-tabular text-lg sm:text-xl leading-none ${textColor}`}>
                      {val}
                    </span>
                  ) : sudoku.notes[idx].length > 0 ? (
                    <div className="grid grid-cols-3 grid-rows-3 w-full h-full p-0.5 text-[8px] leading-none text-neutral-500 dark:text-neutral-400 font-mono-tabular">
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => (
                        <span
                          key={n}
                          className="flex items-center justify-center"
                        >
                          {sudoku.notes[idx].includes(n) ? n : ''}
                        </span>
                      ))}
                    </div>
                  ) : null}
                </button>
              );
            })}
          </div>
        </div>

        {/* Tools & Number Pad */}
        <div className="space-y-3 pt-2">
          <div className="grid grid-cols-4 gap-2">
            <button
              type="button"
              onClick={toggleNotesMode}
              className={`min-h-[52px] rounded-2xl border flex flex-col items-center justify-center gap-1 text-[11px] font-semibold transition-colors cursor-pointer ${
                sudoku.notesMode
                  ? 'bg-[#E03406] text-white border-[#E03406]'
                  : 'bg-white dark:bg-[#231B16] text-neutral-700 dark:text-neutral-200 border-neutral-200/80 dark:border-white/10'
              }`}
            >
              <Pencil className="w-4 h-4" />
              <span>Notes {sudoku.notesMode ? 'On' : 'Off'}</span>
            </button>

            <button
              type="button"
              onClick={handleUndo}
              disabled={sudoku.history.length === 0}
              className="min-h-[52px] rounded-2xl bg-white dark:bg-[#231B16] text-neutral-700 dark:text-neutral-200 border border-neutral-200/80 dark:border-white/10 flex flex-col items-center justify-center gap-1 text-[11px] font-semibold disabled:opacity-40 cursor-pointer"
            >
              <Undo2 className="w-4 h-4" />
              <span>Undo</span>
            </button>

            <button
              type="button"
              onClick={handleErase}
              className="min-h-[52px] rounded-2xl bg-white dark:bg-[#231B16] text-neutral-700 dark:text-neutral-200 border border-neutral-200/80 dark:border-white/10 flex flex-col items-center justify-center gap-1 text-[11px] font-semibold cursor-pointer"
            >
              <Eraser className="w-4 h-4" />
              <span>Erase</span>
            </button>

            <button
              type="button"
              onClick={handleHint}
              className="min-h-[52px] rounded-2xl bg-white dark:bg-[#231B16] text-neutral-700 dark:text-neutral-200 border border-neutral-200/80 dark:border-white/10 flex flex-col items-center justify-center gap-1 text-[11px] font-semibold cursor-pointer"
            >
              <Lightbulb className="w-4 h-4" />
              <span>Hint</span>
            </button>
          </div>

          <div className="grid grid-cols-9 gap-1.5">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
              <button
                key={num}
                type="button"
                onClick={() => handleNumberInput(num)}
                className="min-h-[48px] rounded-xl bg-white dark:bg-[#231B16] border border-neutral-200/80 dark:border-white/10 shadow-sm font-mono-tabular text-lg font-bold text-neutral-900 dark:text-white active:scale-95 hover:bg-neutral-50 dark:hover:bg-white/10 transition-all cursor-pointer"
              >
                {num}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
