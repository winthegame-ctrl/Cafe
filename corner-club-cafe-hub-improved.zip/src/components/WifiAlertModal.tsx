import React from 'react';
import { CheckCircle2, Copy, Wifi, X } from 'lucide-react';
import { WifiStatus } from '../types';

interface WifiAlertModalProps {
  isOpen: boolean;
  wifiStatus: WifiStatus;
  onClose: () => void;
  onJoin: () => void;
  onDisconnect: () => void;
}

const WIFI_SSID = 'Club Wifi';

export const WifiAlertModal: React.FC<WifiAlertModalProps> = ({
  isOpen,
  wifiStatus,
  onClose,
  onJoin,
  onDisconnect,
}) => {
  if (!isOpen) return null;

  const isConfirmed = wifiStatus === 'connected';
  const copyNetworkName = async () => {
    try {
      await navigator.clipboard.writeText(WIFI_SSID);
    } catch {
      // Clipboard access may be unavailable in an insecure browser context.
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/55 backdrop-blur-sm p-0 sm:p-4"
      onClick={onClose}
    >
      <section
        role="dialog"
        aria-modal="true"
        aria-labelledby="wifi-title"
        className="w-full max-w-md rounded-t-[28px] sm:rounded-[28px] bg-white dark:bg-[#211813] text-neutral-900 dark:text-[#F7F3EE] p-5 sm:p-6 shadow-2xl animate-sheet-up"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="h-11 w-11 rounded-2xl bg-emerald-50 dark:bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 flex items-center justify-center">
              {isConfirmed ? <CheckCircle2 className="h-5 w-5" /> : <Wifi className="h-5 w-5" />}
            </div>
            <div>
              <h2 id="wifi-title" className="font-display text-lg font-extrabold tracking-tight">
                {isConfirmed ? 'Wi-Fi marked as joined' : 'Connect to café Wi-Fi'}
              </h2>
              <p className="text-xs text-neutral-500 dark:text-neutral-400">
                {isConfirmed ? 'You confirmed that your device is connected.' : 'A quick connection guide'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Wi-Fi details"
            className="h-9 w-9 rounded-full flex items-center justify-center text-neutral-500 hover:bg-neutral-100 dark:hover:bg-white/10"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="rounded-2xl bg-[#FFF3ED] dark:bg-orange-950/30 border border-orange-100 dark:border-orange-900/50 p-4">
          <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-[#B83A12] dark:text-orange-300">
            Network name
          </p>
          <div className="mt-1 flex items-center justify-between gap-3">
            <span className="font-display text-xl font-extrabold tracking-tight">{WIFI_SSID}</span>
            <button
              type="button"
              onClick={copyNetworkName}
              className="inline-flex min-h-10 items-center gap-2 rounded-xl bg-white dark:bg-white/10 px-3 text-xs font-bold text-neutral-800 dark:text-white shadow-sm"
            >
              <Copy className="h-3.5 w-3.5" /> Copy name
            </button>
          </div>
        </div>

        {!isConfirmed ? (
          <>
            <ol className="mt-5 space-y-3 text-sm text-neutral-700 dark:text-neutral-200">
              <li className="flex gap-3"><span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#E03406] text-xs font-bold text-white">1</span><span>Open Wi-Fi settings on your phone.</span></li>
              <li className="flex gap-3"><span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#E03406] text-xs font-bold text-white">2</span><span>Select <strong>{WIFI_SSID}</strong> from the available networks.</span></li>
              <li className="flex gap-3"><span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#E03406] text-xs font-bold text-white">3</span><span>Ask a member of the café team for the current password if prompted.</span></li>
            </ol>
            <p className="mt-4 rounded-xl bg-neutral-50 dark:bg-white/5 px-3.5 py-3 text-xs leading-relaxed text-neutral-500 dark:text-neutral-400">
              This web app cannot switch your device's Wi-Fi network or verify the connection automatically.
            </p>
            <button
              type="button"
              onClick={() => { onJoin(); onClose(); }}
              className="mt-5 w-full min-h-12 rounded-2xl bg-[#E03406] text-white font-bold text-sm shadow-lg shadow-orange-900/15 hover:bg-[#C92D04] active:scale-[0.99] transition-all"
            >
              I've connected to the Wi-Fi
            </button>
          </>
        ) : (
          <div className="mt-5 space-y-4">
            <p className="text-sm leading-relaxed text-neutral-600 dark:text-neutral-300">
              This status reflects your confirmation only. If you lose the connection, you can reset it below.
            </p>
            <button
              type="button"
              onClick={() => { onDisconnect(); onClose(); }}
              className="w-full min-h-11 rounded-xl border border-neutral-200 dark:border-white/10 text-sm font-semibold text-neutral-700 dark:text-neutral-200 hover:bg-neutral-50 dark:hover:bg-white/5"
            >
              Reset Wi-Fi status
            </button>
            <button
              type="button"
              onClick={onClose}
              className="w-full min-h-11 rounded-xl bg-[#E03406] text-white text-sm font-bold"
            >
              Done
            </button>
          </div>
        )}
      </section>
    </div>
  );
};
