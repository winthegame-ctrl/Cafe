import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';

interface QrCodeCanvasProps {
  value: string;
  size?: number;
  className?: string;
  label?: string;
}

export const QrCodeCanvas: React.FC<QrCodeCanvasProps> = ({
  value,
  size = 152,
  className = '',
  label,
}) => {
  const [svgMarkup, setSvgMarkup] = useState<string>('');

  useEffect(() => {
    let active = true;
    QRCode.toString(value, {
      type: 'svg',
      margin: 1,
      width: size,
      color: {
        dark: '#0A0A0A',
        light: '#FFFFFF',
      },
      errorCorrectionLevel: 'M',
    })
      .then((svg) => {
        if (active) setSvgMarkup(svg);
      })
      .catch(() => {
        if (active) setSvgMarkup('');
      });

    return () => {
      active = false;
    };
  }, [value, size]);

  return (
    <div
      className={`inline-flex flex-col items-center justify-center bg-white rounded-2xl p-3 shadow-sm ${className}`}
    >
      {svgMarkup ? (
        <div
          className="leading-none"
          style={{ width: size, height: size }}
          aria-label={`QR code for ${value}`}
          dangerouslySetInnerHTML={{ __html: svgMarkup }}
        />
      ) : (
        <div
          style={{ width: size, height: size }}
          className="bg-neutral-100 rounded-lg animate-pulse"
        />
      )}
      {label && (
        <span className="mt-1.5 text-[11px] font-medium text-neutral-500 tracking-tight">
          {label}
        </span>
      )}
    </div>
  );
};
