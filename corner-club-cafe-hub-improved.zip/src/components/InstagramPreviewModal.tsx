import React from 'react';
import { Coffee, ExternalLink, Heart, MapPin, Music, Sparkles, X } from 'lucide-react';
import { CornerClubBadge } from './CornerClubBadge';
import { HERO_LATTE_IMAGE, MENU_IMAGE_ASSETS } from '../data/menuData';

interface InstagramPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstagramPreviewModal: React.FC<InstagramPreviewModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const highlights = [
    { label: 'EVENTS', icon: Sparkles },
    { label: 'COUNTER', icon: Coffee },
    { label: 'FESTIVITIES', icon: Music },
    { label: 'COFFEE', icon: Heart },
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/55 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md bg-white dark:bg-[#1E1713] text-neutral-900 dark:text-[#F7F3EE] rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden animate-sheet-up"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-center pt-3 pb-1 sm:hidden">
          <div className="w-10 h-1 rounded-full bg-neutral-300 dark:bg-white/20" />
        </div>

        <div className="flex items-center justify-between px-5 py-3.5 border-b border-neutral-100 dark:border-white/10">
          <span className="font-display font-bold text-base tracking-tight">@cornerclublos</span>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Instagram preview"
            className="w-9 h-9 rounded-full flex items-center justify-center text-neutral-500 hover:bg-neutral-100 dark:hover:bg-white/10 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-5">
          <div className="flex items-center gap-4">
            <div className="p-[3px] rounded-full bg-[#F4511E]">
              <div className="p-[2px] rounded-full bg-white dark:bg-[#1E1713]">
                <CornerClubBadge size="md" />
              </div>
            </div>
            <div className="min-w-0 flex-1">
              <p className="font-display text-lg font-extrabold tracking-tight">CORNER CLUB</p>
              <p className="text-xs text-neutral-500 dark:text-neutral-400">Follow our café updates</p>
            </div>
          </div>

          <div className="space-y-1">
            <div className="font-semibold text-sm">Corner Club</div>
            <div className="text-xs text-neutral-500 dark:text-neutral-400">
              Specialty Café · Neighborhood Bakery
            </div>
            <p className="text-sm leading-snug">
              Fresh pastries, specialty espresso and good company.
            </p>
            <div className="flex items-center gap-1.5 text-xs text-neutral-500 dark:text-neutral-400 pt-1">
              <MapPin className="w-3.5 h-3.5 text-[#E03406]" />
              <span>Open daily · 07:30 – 17:00</span>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-2 pt-1">
            {highlights.map((item) => {
              const Icon = item.icon;
              return (
                <div key={item.label} className="flex flex-col items-center gap-1.5">
                  <div
                    className="w-14 h-14 rounded-full p-[2px] bg-[#F4511E]"
                  >
                    <div className="w-full h-full rounded-full bg-white dark:bg-[#1E1713] flex items-center justify-center">
                      <Icon className="w-5 h-5 text-neutral-800 dark:text-neutral-200" />
                    </div>
                  </div>
                  <span className="text-[10px] font-medium tracking-tight text-neutral-600 dark:text-neutral-400">
                    {item.label}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="grid grid-cols-3 gap-1.5 rounded-2xl overflow-hidden">
            <img
              src={HERO_LATTE_IMAGE}
              alt="Signature latte art at Corner Club"
              referrerPolicy="no-referrer"
              className="aspect-square w-full object-cover"
            />
            <img
              src={MENU_IMAGE_ASSETS.sweet}
              alt="Fresh morning pastries"
              loading="lazy"
              referrerPolicy="no-referrer"
              className="aspect-square w-full object-cover"
            />
            <img
              src={MENU_IMAGE_ASSETS.brunch}
              alt="Weekend sourdough brunch"
              loading="lazy"
              referrerPolicy="no-referrer"
              className="aspect-square w-full object-cover"
            />
          </div>

          <a
            href="https://www.instagram.com/cornerclublos/"
            target="_blank"
            rel="noopener noreferrer"
            className="w-full min-h-[46px] rounded-2xl bg-neutral-950 dark:bg-white text-white dark:text-neutral-950 font-semibold text-sm flex items-center justify-center gap-2 active:scale-[0.98] transition-transform"
          >
            <span>Open Instagram</span>
            <ExternalLink className="w-4 h-4" />
          </a>
        </div>
      </div>
    </div>
  );
};
