import React, { useEffect, useState } from 'react';
import { Check, Heart, ShieldCheck, Wallet, X } from 'lucide-react';
import { CustomerPass } from '../types';
import { HERO_LATTE_IMAGE } from '../data/menuData';
import { CornerClubBadge } from './CornerClubBadge';
import { QrCodeCanvas } from './QrCodeCanvas';

interface RegistrationPassModalProps {
  isOpen: boolean;
  onClose: () => void;
  onComplete: (pass: CustomerPass) => void;
}

const MONTHS = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

const DAYS = Array.from({ length: 31 }, (_, i) => String(i + 1));

type ModalStep = 'form' | 'building' | 'ready' | 'wallet-sheet';

export const RegistrationPassModal: React.FC<RegistrationPassModalProps> = ({
  isOpen,
  onClose,
  onComplete,
}) => {
  const [step, setStep] = useState<ModalStep>('form');
  const [buildPhase, setBuildPhase] = useState<number>(0);

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [birthMonth, setBirthMonth] = useState('');
  const [birthDay, setBirthDay] = useState('');
  const [marketingOptIn, setMarketingOptIn] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [showPrivacyNote, setShowPrivacyNote] = useState(false);

  const [createdPass, setCreatedPass] = useState<CustomerPass | null>(null);

  useEffect(() => {
    if (!isOpen) {
      setStep('form');
      setBuildPhase(0);
      setErrorMsg('');
      setShowPrivacyNote(false);
    }
  }, [isOpen]);

  useEffect(() => {
    if (step !== 'building') return;
    setBuildPhase(1);
    const t1 = window.setTimeout(() => setBuildPhase(2), 380);
    const t2 = window.setTimeout(() => setBuildPhase(3), 780);
    const t3 = window.setTimeout(() => setBuildPhase(4), 1180);
    const t4 = window.setTimeout(() => {
      setStep('ready');
    }, 1650);

    return () => {
      window.clearTimeout(t1);
      window.clearTimeout(t2);
      window.clearTimeout(t3);
      window.clearTimeout(t4);
    };
  }, [step]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = name.trim();
    const trimmedEmail = email.trim();

    if (!trimmedName) {
      setErrorMsg('Please enter your name to create your loyalty card.');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)) {
      setErrorMsg('Please enter a valid email address.');
      return;
    }

    setErrorMsg('');
    const pass: CustomerPass = {
      id: `CC-${Math.random().toString(36).substring(2, 8).toUpperCase()}`,
      name: trimmedName,
      email: trimmedEmail,
      birthMonth,
      birthDay,
      marketingOptIn,
      stamps: 0,
      redeemedCount: 0,
      walletAdded: false,
      createdAt: new Date().toISOString(),
    };
    setCreatedPass(pass);
    setStep('building');
  };

  const handleFinish = (addedToWallet: boolean) => {
    if (!createdPass) return;
    onComplete({ ...createdPass, walletAdded: addedToWallet });
    onClose();
  };

  if (step === 'form') {
    return (
      <div
        className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/55 backdrop-blur-sm"
        onClick={onClose}
      >
        <div
          className="w-full max-w-md bg-[#E03406] dark:bg-[#B82A04] text-white rounded-t-[28px] sm:rounded-[28px] shadow-2xl overflow-hidden animate-sheet-up max-h-[92vh] flex flex-col"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-center justify-between px-5 pt-3 pb-1">
            <div className="w-9" />
            <div className="w-10 h-1 rounded-full bg-white/35" />
            <button
              type="button"
              onClick={onClose}
              aria-label="Close registration"
              className="w-9 h-9 rounded-full flex items-center justify-center text-white/80 hover:bg-white/15 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="px-6 pt-2 pb-7 overflow-y-auto space-y-4">
            <div className="flex flex-col items-center text-center">
              <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center mb-3 shadow-inner">
                <div className="w-9 h-9 rounded-full bg-white flex items-center justify-center">
                  <Heart className="w-5 h-5 text-[#E03406] fill-[#E03406]" />
                </div>
              </div>
              <h2 className="font-display text-2xl font-bold tracking-tight">Earn Rewards</h2>
              <p className="text-sm text-white/90 mt-1">
                Collect 8 stamps to earn a free Coffee
              </p>
            </div>

            <div className="space-y-3 pt-1">
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Your name"
                autoComplete="name"
                className="w-full min-h-[48px] px-4 rounded-xl bg-white text-neutral-900 placeholder:text-neutral-400 text-[15px] font-medium outline-none focus:ring-2 focus:ring-white/80"
              />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email address"
                autoComplete="email"
                className="w-full min-h-[48px] px-4 rounded-xl bg-white text-neutral-900 placeholder:text-neutral-400 text-[15px] font-medium outline-none focus:ring-2 focus:ring-white/80"
              />
            </div>

            <div className="space-y-2">
              <p className="text-[12px] text-white/85 text-center leading-snug">
                Leave your birthday if you&apos;d like to receive birthday rewards
              </p>
              <div className="grid grid-cols-2 gap-3">
                <select
                  aria-label="Birth month"
                  value={birthMonth}
                  onChange={(e) => setBirthMonth(e.target.value)}
                  className="w-full min-h-[46px] px-3.5 rounded-xl bg-white text-neutral-900 text-[15px] font-medium outline-none focus:ring-2 focus:ring-white/80"
                >
                  <option value="">Month</option>
                  {MONTHS.map((m) => (
                    <option key={m} value={m}>
                      {m}
                    </option>
                  ))}
                </select>
                <select
                  aria-label="Birth day"
                  value={birthDay}
                  onChange={(e) => setBirthDay(e.target.value)}
                  className="w-full min-h-[46px] px-3.5 rounded-xl bg-white text-neutral-900 text-[15px] font-medium outline-none focus:ring-2 focus:ring-white/80"
                >
                  <option value="">Day</option>
                  {DAYS.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>
              <p className="text-[11px] text-white/75 text-center">
                Add the day too, or leave both blank.
              </p>
            </div>

            <label className="flex items-center gap-3 pt-1 cursor-pointer select-none min-h-[44px]">
              <input
                type="checkbox"
                checked={marketingOptIn}
                onChange={(e) => setMarketingOptIn(e.target.checked)}
                className="w-5 h-5 rounded border-2 border-white/70 accent-neutral-950 cursor-pointer"
              />
              <span className="text-sm font-medium text-white">
                Email me offers from CORNER CLUB.
              </span>
            </label>

            {errorMsg && (
              <div className="px-3.5 py-2.5 rounded-xl bg-black/25 text-xs font-medium text-white flex items-center gap-2">
                <span>{errorMsg}</span>
              </div>
            )}

            <button
              type="submit"
              className="w-full min-h-[50px] rounded-xl bg-white text-[#E03406] font-display font-bold text-[15px] shadow-lg active:scale-[0.98] transition-transform cursor-pointer"
            >
              Get your loyalty card
            </button>

            <div className="text-center text-[11px] text-white/80 leading-relaxed">
              By joining you confirm you&apos;re 13+ and have read the{' '}
              <button
                type="button"
                onClick={() => setShowPrivacyNote((prev) => !prev)}
                className="underline font-semibold hover:text-white"
              >
                Privacy notice
              </button>
              .
              {showPrivacyNote && (
                <div className="mt-2 p-3 rounded-xl bg-black/25 text-left text-white/90">
                  CORNER CLUB &amp; TablePass store your loyalty card locally on this device so your
                  stamps and birthday perks stay available without tracking.
                </div>
              )}
            </div>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm">
      <div className="w-full max-w-md bg-[#F7F6F5] dark:bg-[#1B1512] text-neutral-900 dark:text-[#F7F3EE] rounded-t-[28px] sm:rounded-[28px] shadow-2xl overflow-hidden animate-sheet-up max-h-[94vh] flex flex-col">
        {step === 'wallet-sheet' ? (
          <div className="flex flex-col">
            <div className="flex items-center justify-between px-4 py-3.5 border-b border-neutral-200 dark:border-white/10">
              <button
                type="button"
                onClick={() => setStep('ready')}
                aria-label="Close loyalty card preview"
                className="w-9 h-9 rounded-full bg-neutral-200/80 dark:bg-white/10 flex items-center justify-center text-neutral-700 dark:text-neutral-200"
              >
                <X className="w-4 h-4" />
              </button>
              <span className="font-semibold text-[15px]">Loyalty card preview</span>
              <button
                type="button"
                onClick={() => handleFinish(true)}
                className="px-4 py-1.5 rounded-full bg-[#E03406] text-white text-sm font-semibold active:scale-95 transition-transform"
              >
                Save
              </button>
            </div>
            <div className="p-5">
              {createdPass && (
                <WalletPassCard pass={createdPass} phase={4} />
              )}
              <div className="mt-4 flex items-center justify-center gap-2 text-xs text-neutral-500 dark:text-neutral-400">
                <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>Preview of your CORNER CLUB loyalty card</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="px-5 pt-4 pb-6 overflow-y-auto">
            <div className="flex justify-center mb-3">
              <div className="w-10 h-1 rounded-full bg-neutral-300 dark:bg-white/20" />
            </div>

            <h2 className="text-center font-display text-lg font-bold tracking-tight mb-4">
              {step === 'building' ? 'Building your pass...' : 'Your pass is ready'}
            </h2>

            {createdPass && (
              <WalletPassCard
                pass={createdPass}
                phase={step === 'ready' ? 4 : buildPhase}
              />
            )}

            <div className="mt-5 space-y-2.5">
              <button
                type="button"
                disabled={step === 'building'}
                onClick={() => setStep('wallet-sheet')}
                className={`w-full min-h-[48px] rounded-xl font-semibold text-[15px] flex items-center justify-center gap-2 border transition-all ${
                  step === 'building'
                    ? 'bg-neutral-200 dark:bg-white/5 text-neutral-400 border-transparent cursor-not-allowed'
                    : 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white border-neutral-200 dark:border-white/15 shadow-sm hover:bg-neutral-50 active:scale-[0.98] cursor-pointer'
                }`}
              >
                <Wallet className="w-4 h-4" />
                <span>Preview your loyalty card</span>
              </button>

              <button
                type="button"
                disabled={step === 'building'}
                onClick={() => handleFinish(false)}
                className={`w-full min-h-[48px] rounded-xl font-semibold text-[15px] flex items-center justify-center gap-2 transition-all ${
                  step === 'building'
                    ? 'bg-[#E03406]/30 text-white/60 cursor-not-allowed'
                    : 'bg-[#FBE4DD] dark:bg-[#E03406] text-[#D83206] dark:text-white hover:opacity-95 active:scale-[0.98] cursor-pointer'
                }`}
              >
                <Check className="w-4 h-4" />
                <span>Done</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

interface WalletPassCardProps {
  pass: CustomerPass;
  phase: number;
}

export const WalletPassCard: React.FC<WalletPassCardProps> = ({ pass, phase }) => {
  return (
    <div className="rounded-2xl bg-[#EB3B0A] text-white shadow-xl overflow-hidden transition-all duration-300">
      {/* Header strip */}
      <div className="flex items-center justify-between px-4 py-3">
        <div
          className={`flex items-center gap-2.5 transition-all duration-300 ${
            phase >= 2 ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'
          }`}
        >
          <CornerClubBadge variant="square" size="sm" />
          <span className="font-display font-extrabold tracking-tight text-sm uppercase">
            CORNER CLUB
          </span>
        </div>
        <div
          className={`text-right transition-all duration-300 ${
            phase >= 2 ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'
          }`}
        >
          <div className="text-[9px] font-bold tracking-wider uppercase text-white/80">
            STAMPS
          </div>
          <div className="font-mono-tabular font-bold text-sm leading-none">
            {pass.stamps} / 8
          </div>
        </div>
      </div>

      {/* Hero coffee strip */}
      <div
        className={`relative h-28 w-full overflow-hidden bg-black/20 transition-all duration-500 ${
          phase >= 3 ? 'opacity-100' : 'opacity-0'
        }`}
      >
        <img
          src={HERO_LATTE_IMAGE}
          alt="Corner Club Latte Art"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/35 via-transparent to-transparent" />
      </div>

      {/* Stamp tracker */}
      <div className="px-4 pt-3 pb-4">
        <div
          className={`transition-all duration-300 ${
            phase >= 4 ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'
          }`}
        >
          <div className="flex items-center justify-between text-[10px] font-bold tracking-wider uppercase text-white/90 mb-2">
            <span>FREE COFFEE · 8 STAMPS</span>
            <span className="truncate max-w-[140px]">{pass.name}</span>
          </div>

          <div className="flex items-center gap-2 mb-5">
            {Array.from({ length: 8 }).map((_, idx) => {
              const filled = idx < pass.stamps;
              return (
                <div
                  key={idx}
                  className={`w-5 h-5 rounded-full border-2 transition-all duration-200 flex items-center justify-center ${
                    filled
                      ? 'bg-white border-white text-[#EB3B0A] scale-105'
                      : 'border-white/80 bg-transparent'
                  }`}
                >
                  {filled && <Check className="w-3 h-3 stroke-[3]" />}
                </div>
              );
            })}
          </div>
        </div>

        {/* Scannable QR box */}
        <div
          className={`flex justify-center transition-all duration-500 ${
            phase >= 4 ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
          }`}
        >
          <QrCodeCanvas
            value={`TABLEPASS:CORNERCLUB:${pass.id}:${pass.stamps}`}
            size={136}
            label="Powered by TablePass"
          />
        </div>
      </div>
    </div>
  );
};
