import React, { useRef, useState } from 'react';
import { Camera, CheckCircle2, Info, Trash2, X } from 'lucide-react';
import { CornerClubBadge } from './CornerClubBadge';

interface FeedbackSheetProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmitFeedback: (message: string, photoDataUrl: string | null) => void;
}

export const FeedbackSheet: React.FC<FeedbackSheetProps> = ({
  isOpen,
  onClose,
  onSubmitFeedback,
}) => {
  const [message, setMessage] = useState('');
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [photoName, setPhotoName] = useState<string>('');
  const [showInfo, setShowInfo] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [fileError, setFileError] = useState('');
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 1024 * 1024) {
      setFileError('Please choose an image smaller than 1 MB.');
      e.target.value = '';
      return;
    }
    setFileError('');
    setPhotoName(file.name);
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setPhotoPreview(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    onSubmitFeedback(message.trim(), photoPreview);
    setSubmitted(true);
    window.setTimeout(() => {
      setMessage('');
      setPhotoPreview(null);
      setPhotoName('');
      setFileError('');
      setSubmitted(false);
      onClose();
    }, 1800);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/55 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md bg-[#E03406] dark:bg-[#B82A04] text-white rounded-t-[28px] sm:rounded-[28px] shadow-2xl overflow-hidden animate-sheet-up"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-5 pt-3 pb-2 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <CornerClubBadge size="sm" />
            <span className="font-display font-extrabold tracking-tight text-base uppercase">
              CORNER CLUB
            </span>
          </div>
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => setShowInfo((prev) => !prev)}
              aria-label="Anonymity information"
              className="w-9 h-9 rounded-full flex items-center justify-center text-white/90 hover:bg-white/15 transition-colors"
            >
              <Info className="w-5 h-5" />
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close suggestion box"
              className="w-9 h-9 rounded-full flex items-center justify-center text-white/90 hover:bg-white/15 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {showInfo && (
          <div className="mx-5 mb-2 p-3 rounded-2xl bg-black/25 text-xs text-white/95 leading-relaxed">
            Your feedback is saved in this browser on this device. It is not sent to the café team yet.
          </div>
        )}

        {submitted ? (
          <div className="px-6 py-14 text-center space-y-3 animate-stamp-pop">
            <div className="w-14 h-14 rounded-full bg-white/20 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8 text-white" />
            </div>
            <h3 className="font-display text-2xl font-bold">Thank you!</h3>
            <p className="text-sm text-white/90">
              Thank you. Your feedback has been saved on this device.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="px-5 pt-2 pb-7 space-y-4">
            <div>
              <h2 className="font-display text-[28px] font-extrabold tracking-tight leading-tight">
                Honest Feedback
              </h2>
              <p className="text-sm text-white/90 mt-1">
                Tell us what you think. Your message stays saved on this device.
              </p>
            </div>

            <textarea
              rows={5}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Tell us what you loved, or what we could do better."
              className="w-full p-4 rounded-2xl bg-black/35 text-white placeholder:text-white/55 text-[15px] leading-relaxed outline-none focus:ring-2 focus:ring-white/80 resize-none"
            />

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="hidden"
            />

            {fileError && (
              <p role="alert" className="text-xs font-semibold text-white bg-black/25 rounded-xl px-3 py-2">{fileError}</p>
            )}

            {photoPreview ? (
              <div className="flex items-center justify-between p-2.5 rounded-2xl bg-black/25">
                <div className="flex items-center gap-3 min-w-0">
                  <img
                    src={photoPreview}
                    alt="Attached feedback preview"
                    className="w-12 h-12 rounded-xl object-cover shrink-0"
                  />
                  <span className="text-xs font-medium truncate">{photoName || 'Attached photo'}</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setPhotoPreview(null);
                    setPhotoName('');
                    if (fileInputRef.current) fileInputRef.current.value = '';
                  }}
                  aria-label="Remove attached photo"
                  className="w-9 h-9 rounded-full flex items-center justify-center text-white/80 hover:bg-white/15"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="inline-flex items-center gap-2 min-h-[44px] px-3 py-2 -ml-1 rounded-xl text-sm font-semibold text-white hover:bg-white/10 transition-colors cursor-pointer"
              >
                <Camera className="w-4 h-4" />
                <span>Attach Photo</span>
              </button>
            )}

            <button
              type="submit"
              disabled={!message.trim()}
              className={`w-full min-h-[50px] rounded-2xl font-display font-bold text-[15px] transition-all ${
                message.trim()
                  ? 'bg-white text-[#E03406] shadow-lg active:scale-[0.98] cursor-pointer'
                  : 'bg-white/55 text-[#E03406]/60 cursor-not-allowed'
              }`}
            >
              Send Feedback
            </button>

            <p className="text-center text-[11px] text-white/80">
              Your feedback is stored locally in this browser. A connected submission service is not configured yet.
            </p>
          </form>
        )}
      </div>
    </div>
  );
};
