import React, { useEffect, useState } from 'react';
import {
  BookOpen,
  Check,
  Clock,
  Coffee,
  Grid3X3,
  Heart,
  Inbox,
  Loader2,
  Moon,
  QrCode,
  Sun,
  Wifi,
} from 'lucide-react';
import {
  CustomerPass,
  FeedbackEntry,
  SudokuState,
  ThemeMode,
  WifiStatus,
} from './types';
import { HERO_LATTE_IMAGE } from './data/menuData';
import { createSudokuPuzzle } from './utils/sudoku';
import { CornerClubBadge } from './components/CornerClubBadge';
import { RegistrationPassModal } from './components/RegistrationPassModal';
import { LoyaltyQrModal } from './components/LoyaltyQrModal';
import { MenuSheet } from './components/MenuSheet';
import { WifiAlertModal } from './components/WifiAlertModal';
import { SudokuScreen } from './components/SudokuScreen';
import { FeedbackSheet } from './components/FeedbackSheet';
import { InstagramPreviewModal } from './components/InstagramPreviewModal';

const STORAGE_KEYS = {
  PASS: 'corner_club_loyalty_pass_v1',
  THEME: 'corner_club_theme_v1',
  WIFI: 'corner_club_wifi_v1',
  SUDOKU: 'corner_club_sudoku_v1',
  FEEDBACK: 'corner_club_feedback_v1',
};

function readStorage<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export default function App() {
  const [theme, setTheme] = useState<ThemeMode>(() =>
    readStorage<ThemeMode>(STORAGE_KEYS.THEME, 'orange')
  );
  const [customerPass, setCustomerPass] = useState<CustomerPass | null>(() =>
    readStorage<CustomerPass | null>(STORAGE_KEYS.PASS, null)
  );
  const [wifiStatus, setWifiStatus] = useState<WifiStatus>(() => {
    const saved = readStorage<WifiStatus>(STORAGE_KEYS.WIFI, 'idle');
    return saved === 'connecting' ? 'idle' : saved;
  });
  const [sudokuState, setSudokuState] = useState<SudokuState>(() =>
    readStorage<SudokuState>(STORAGE_KEYS.SUDOKU, createSudokuPuzzle('easy'))
  );
  const [feedbackLogs, setFeedbackLogs] = useState<FeedbackEntry[]>(() =>
    readStorage<FeedbackEntry[]>(STORAGE_KEYS.FEEDBACK, [])
  );

  // Active modal / view states
  const [showRegisterModal, setShowRegisterModal] = useState(false);
  const [showQrModal, setShowQrModal] = useState(false);
  const [showMenuSheet, setShowMenuSheet] = useState(false);
  const [showWifiModal, setShowWifiModal] = useState(false);
  const [showSudoku, setShowSudoku] = useState(false);
  const [showFeedbackSheet, setShowFeedbackSheet] = useState(false);
  const [showInstagramModal, setShowInstagramModal] = useState(false);
  const [heroImgFailed, setHeroImgFailed] = useState(false);

  // Sync Tailwind dark class & localStorage
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    window.localStorage.setItem(STORAGE_KEYS.THEME, JSON.stringify(theme));
  }, [theme]);

  useEffect(() => {
    window.localStorage.setItem(STORAGE_KEYS.PASS, JSON.stringify(customerPass));
  }, [customerPass]);

  useEffect(() => {
    window.localStorage.setItem(STORAGE_KEYS.WIFI, JSON.stringify(wifiStatus));
  }, [wifiStatus]);

  useEffect(() => {
    window.localStorage.setItem(STORAGE_KEYS.SUDOKU, JSON.stringify(sudokuState));
  }, [sudokuState]);

  useEffect(() => {
    window.localStorage.setItem(STORAGE_KEYS.FEEDBACK, JSON.stringify(feedbackLogs));
  }, [feedbackLogs]);

  const handleJoinWifi = () => {
    // The browser cannot verify or force a device-level Wi-Fi connection.
    // This status is only updated after the customer confirms they joined.
    setWifiStatus('connected');
  };

  const handleRedeemFreeCoffee = () => {
    setCustomerPass((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        stamps: 0,
        redeemedCount: prev.redeemedCount + 1,
      };
    });
  };

  const handleSubmitFeedback = (message: string, photoDataUrl: string | null) => {
    setFeedbackLogs((prev) => [
      {
        id: `fb-${Date.now()}`,
        message,
        hasPhoto: Boolean(photoDataUrl),
        ...(photoDataUrl ? { photoDataUrl } : {}),
        createdAt: new Date().toISOString(),
      },
      ...prev,
    ]);
  };

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'orange' ? 'dark' : 'orange'));
  };

  const stampsCount = customerPass?.stamps ?? 0;

  return (
    <div
      className={`min-h-screen w-full transition-colors duration-300 ${
        theme === 'dark'
          ? 'bg-[#17110E] text-[#F7F3EE]'
          : 'bg-[#F4511E] text-white'
      }`}
    >
      {/* Desktop responsive stage wrapper: pure full-screen mobile portrait on mobile, balanced café counter showcase on desktop */}
      <div className="mx-auto max-w-7xl lg:px-8 lg:py-8 lg:grid lg:grid-cols-12 lg:gap-10 lg:items-center min-h-screen">
        {/* Main Mobile Hub Portrait Frame */}
        <main
          className={`w-full max-w-md mx-auto lg:col-span-6 min-h-screen lg:min-h-[780px] lg:rounded-[40px] lg:shadow-2xl overflow-hidden flex flex-col justify-between transition-colors duration-300 ${
            theme === 'dark'
              ? 'bg-[#1B1410] text-[#F7F3EE] lg:border lg:border-white/10'
              : 'bg-[#F4511E] text-white'
          }`}
        >
          <div>
            {/* Top Latte Art Hero Banner */}
            <div className="relative h-44 sm:h-48 w-full overflow-hidden bg-neutral-900">
              {!heroImgFailed ? (
                <img
                  src={HERO_LATTE_IMAGE}
                  alt="Corner Club Latte Art"
                  referrerPolicy="no-referrer"
                  onError={() => setHeroImgFailed(true)}
                  className="w-full h-full object-cover object-center"
                />
              ) : (
                <div className="w-full h-full bg-[#B83A12] flex items-center justify-center">
                  <Coffee className="w-12 h-12 text-white/60" />
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-b from-black/25 via-transparent to-black/35" />

              {/* Theme Switcher Button (top right of hero) */}
              <button
                type="button"
                onClick={toggleTheme}
                aria-label={
                  theme === 'dark'
                    ? 'Switch to Vibrant Orange theme'
                    : 'Switch to Espresso Dark theme'
                }
                title={
                  theme === 'dark' ? 'Switch to Vibrant Orange' : 'Switch to Espresso Dark'
                }
                className="absolute top-3.5 right-3.5 min-h-[40px] px-3 rounded-full bg-black/45 hover:bg-black/60 backdrop-blur-md text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                {theme === 'dark' ? (
                  <>
                    <Sun className="w-3.5 h-3.5 text-orange-400" />
                    <span>Orange</span>
                  </>
                ) : (
                  <>
                    <Moon className="w-3.5 h-3.5" />
                    <span>Espresso</span>
                  </>
                )}
              </button>
            </div>

            {/* Café Identity Header Row */}
            <div className="px-5 relative -mt-7 flex items-end gap-3.5 pb-6">
              <CornerClubBadge size="lg" />
              <div className="pb-1 min-w-0">
                <h1 className="font-display text-[23px] font-extrabold tracking-tight leading-tight text-white uppercase truncate">
                  CORNER CLUB
                </h1>
                <p className="text-[13px] font-medium text-white/90 truncate">
                  Food - Coffee - Smoothies
                </p>
              </div>
            </div>

            {/* Action Cards Stack */}
            <div className="px-4 space-y-3.5">
              {/* 1. Loyalty Card */}
              {!customerPass ? (
                <button
                  type="button"
                  onClick={() => setShowRegisterModal(true)}
                  className="w-full min-h-[60px] bg-white dark:bg-[#261D17] text-neutral-900 dark:text-[#F7F3EE] rounded-[20px] shadow-md px-5 py-4 flex items-center justify-between active:scale-[0.99] transition-transform cursor-pointer text-left"
                >
                  <div className="flex items-center gap-3.5">
                    <div className="w-8 h-8 rounded-full bg-red-50 dark:bg-red-500/15 flex items-center justify-center shrink-0">
                      <Heart className="w-4 h-4 text-[#E03406] fill-[#E03406]" />
                    </div>
                    <span className="font-semibold text-[15px] tracking-tight">
                      Start earning rewards
                    </span>
                  </div>
                </button>
              ) : (
                <div className="w-full bg-white dark:bg-[#261D17] text-neutral-900 dark:text-[#F7F3EE] rounded-[22px] shadow-md p-4 space-y-3.5">
                  <div className="flex items-center gap-2.5">
                    <Heart className="w-4 h-4 text-[#E03406] fill-[#E03406] shrink-0" />
                    <span className="text-[14px] font-semibold tracking-tight">
                      <span className="font-mono-tabular">{stampsCount} / 8</span> stamps towards a
                      free coffee
                    </span>
                  </div>

                  {/* 8-Circle Visual Progress Bar */}
                  <div
                    className="flex items-center justify-between gap-1.5 px-0.5"
                    aria-label={`${stampsCount} of 8 loyalty stamps earned`}
                  >
                    {Array.from({ length: 8 }).map((_, idx) => {
                      const earned = idx < stampsCount;
                      return (
                        <div
                          key={idx}
                          className={`w-7 h-7 rounded-full border-2 flex items-center justify-center transition-all duration-200 ${
                            earned
                              ? 'bg-[#E03406] border-[#E03406] text-white animate-stamp-pop'
                              : 'bg-white dark:bg-transparent border-[#E03406]/70'
                          }`}
                        >
                          {earned && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                        </div>
                      );
                    })}
                  </div>

                  <button
                    type="button"
                    onClick={() => setShowQrModal(true)}
                    className="w-full min-h-[46px] rounded-2xl bg-neutral-950 dark:bg-[#F5410B] text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-sm hover:opacity-95 active:scale-[0.98] transition-all cursor-pointer"
                  >
                    <QrCode className="w-4 h-4" />
                    <span>
                      {stampsCount >= 8 ? 'Claim free coffee' : 'Show my QR code'}
                    </span>
                  </button>
                </div>
              )}

              {/* 2. View Menu */}
              <button
                type="button"
                onClick={() => setShowMenuSheet(true)}
                className="w-full min-h-[60px] bg-white dark:bg-[#261D17] text-neutral-900 dark:text-[#F7F3EE] rounded-[20px] shadow-md px-5 py-4 flex items-center justify-between active:scale-[0.99] transition-transform cursor-pointer text-left"
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-8 h-8 rounded-xl bg-orange-50 dark:bg-orange-500/15 flex items-center justify-center shrink-0">
                    <BookOpen className="w-4 h-4 text-[#F57C00]" />
                  </div>
                  <span className="font-semibold text-[15px] tracking-tight">View Menu</span>
                </div>
              </button>

              {/* 3. Connect to Wi-Fi */}
              <button
                type="button"
                onClick={() => {
                  if (wifiStatus !== 'connecting') setShowWifiModal(true);
                }}
                className="w-full min-h-[60px] bg-white dark:bg-[#261D17] text-neutral-900 dark:text-[#F7F3EE] rounded-[20px] shadow-md px-5 py-4 flex items-center justify-between active:scale-[0.99] transition-transform cursor-pointer text-left"
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-500/15 flex items-center justify-center shrink-0">
                    {wifiStatus === 'connecting' ? (
                      <Loader2 className="w-4 h-4 text-neutral-600 dark:text-neutral-300 animate-spin" />
                    ) : (
                      <Wifi className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                    )}
                  </div>
                  <span className="font-semibold text-[15px] tracking-tight">
                    {wifiStatus === 'connecting'
                      ? 'Connecting...'
                      : wifiStatus === 'connected'
                        ? 'Wi-Fi marked as joined'
                        : 'Connect to Wi-Fi'}
                  </span>
                </div>
                {wifiStatus === 'connected' && (
                  <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                    View
                  </span>
                )}
              </button>

              {/* 4. Play Sudoku */}
              <button
                type="button"
                onClick={() => setShowSudoku(true)}
                className="w-full min-h-[60px] bg-white dark:bg-[#261D17] text-neutral-900 dark:text-[#F7F3EE] rounded-[20px] shadow-md px-5 py-4 flex items-center justify-between active:scale-[0.99] transition-transform cursor-pointer text-left"
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-8 h-8 rounded-xl bg-orange-50 dark:bg-orange-500/15 flex items-center justify-center shrink-0">
                    <Grid3X3 className="w-4 h-4 text-[#E03406] dark:text-orange-300" />
                  </div>
                  <span className="font-semibold text-[15px] tracking-tight">Play Sudoku</span>
                </div>
              </button>

              {/* 5. Suggestion Box */}
              <button
                type="button"
                onClick={() => setShowFeedbackSheet(true)}
                className="w-full min-h-[60px] bg-white dark:bg-[#261D17] text-neutral-900 dark:text-[#F7F3EE] rounded-[20px] shadow-md px-5 py-4 flex items-center justify-between active:scale-[0.99] transition-transform cursor-pointer text-left"
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-8 h-8 rounded-xl bg-orange-50 dark:bg-orange-500/15 flex items-center justify-center shrink-0">
                    <Inbox className="w-4 h-4 text-[#E03406] dark:text-orange-300" />
                  </div>
                  <span className="font-semibold text-[15px] tracking-tight">Suggestion Box</span>
                </div>
              </button>
            </div>
          </div>

          {/* Footer: Instagram & Powered by TablePass */}
          <footer className="px-4 pt-6 pb-7 flex flex-col items-center gap-3.5">
            <button
              type="button"
              onClick={() => setShowInstagramModal(true)}
              aria-label="Open Corner Club Instagram"
              className="w-11 h-11 rounded-[14px] bg-[#E03406] p-[2px] shadow-md hover:scale-105 active:scale-95 transition-transform cursor-pointer"
            >
              <div className="w-full h-full rounded-[12px] flex items-center justify-center text-white">
                <svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.1"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="w-5 h-5"
                  aria-hidden="true"
                >
                  <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                  <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
                </svg>
              </div>
            </button>

            <div className="flex items-center gap-1.5 text-xs font-semibold text-white/90">
              <Heart className="w-3.5 h-3.5 fill-white/90 text-white/90" />
              <span>Powered by TablePass</span>
            </div>
          </footer>
        </main>

        {/* Desktop Companion Context Panel (hidden on mobile to preserve exact reference portrait flow) */}
        <aside
          className={`hidden lg:flex lg:col-span-6 flex-col gap-6 p-8 rounded-[32px] ${
            theme === 'dark'
              ? 'bg-[#211813] border border-white/10 text-[#F7F3EE]'
              : 'bg-white text-neutral-900 shadow-sm border border-neutral-200/70'
          }`}
        >
          <div className="space-y-2">
            <div className="text-xs font-bold uppercase tracking-wider text-[#E03406]">
              Tabletop NFC &amp; QR Customer Hub
            </div>
            <h2 className="font-display text-3xl font-extrabold tracking-tight text-balance">
              Welcome to CORNER CLUB
            </h2>
            <p className="text-sm leading-relaxed text-neutral-600 dark:text-neutral-300 max-w-prose">
              Tap through the live mobile hub on the left to register a digital TablePass loyalty
              card, add stamps at the counter, browse our sourdough brunch &amp; drinks menu, join
              Club Wifi, or unwind with a game of Sudoku.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4 pt-2 border-t border-neutral-200/70 dark:border-white/10">
            <div className="space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-neutral-500 dark:text-neutral-400">
                <Clock className="w-3.5 h-3.5 text-[#E03406]" />
                <span>Opening Hours</span>
              </div>
              <div className="font-display font-bold text-base">07:30 – 17:00 Daily</div>
              <div className="text-xs text-neutral-500 dark:text-neutral-400">
                Kitchen until 15:30
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-neutral-500 dark:text-neutral-400">
                <Wifi className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span>Guest Wi-Fi</span>
              </div>
              <div className="font-display font-bold text-base">Club Wifi</div>
              <div className="text-xs text-neutral-500 dark:text-neutral-400">
                Status:{' '}
                <span className="font-semibold">
                  {wifiStatus === 'connected' ? 'Customer confirmed' : 'Ready to join'}
                </span>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-neutral-100 dark:bg-white/5 flex items-center justify-between gap-4">
            <div>
              <div className="text-xs font-semibold text-neutral-500 dark:text-neutral-400">
                Loyalty Status
              </div>
              <div className="font-display font-bold text-base mt-0.5">
                {customerPass
                  ? `${customerPass.name} · ${customerPass.stamps}/8 stamps`
                  : 'Not enrolled yet'}
              </div>
            </div>
            <button
              type="button"
              onClick={() =>
                customerPass ? setShowQrModal(true) : setShowRegisterModal(true)
              }
              className="px-4 py-2.5 rounded-xl bg-[#E03406] text-white text-xs font-bold hover:bg-[#c92d04] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {customerPass ? 'Open Pass' : 'Create Pass'}
            </button>
          </div>
        </aside>
      </div>

      {/* Modals & Overlays */}
      <RegistrationPassModal
        isOpen={showRegisterModal}
        onClose={() => setShowRegisterModal(false)}
        onComplete={(pass) => setCustomerPass(pass)}
      />

      <LoyaltyQrModal
        isOpen={showQrModal}
        pass={customerPass}
        onClose={() => setShowQrModal(false)}
        onRedeemFreeCoffee={handleRedeemFreeCoffee}
        onResetPass={() => setCustomerPass(null)}
      />

      <MenuSheet isOpen={showMenuSheet} onClose={() => setShowMenuSheet(false)} />

      <WifiAlertModal
        isOpen={showWifiModal}
        wifiStatus={wifiStatus}
        onClose={() => setShowWifiModal(false)}
        onJoin={handleJoinWifi}
        onDisconnect={() => setWifiStatus('idle')}
      />

      <SudokuScreen
        isOpen={showSudoku}
        sudoku={sudokuState}
        onUpdateSudoku={setSudokuState}
        onBack={() => setShowSudoku(false)}
      />

      <FeedbackSheet
        isOpen={showFeedbackSheet}
        onClose={() => setShowFeedbackSheet(false)}
        onSubmitFeedback={handleSubmitFeedback}
      />

      <InstagramPreviewModal
        isOpen={showInstagramModal}
        onClose={() => setShowInstagramModal(false)}
      />
    </div>
  );
}
