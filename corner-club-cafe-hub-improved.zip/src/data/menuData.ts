import { MenuItem } from '../types';
import heroLatte from '../assets/images/hero_latte_art_1795232888951.jpg';
import brunchImage from '../assets/images/menu_brunch_plate_1795232890513.jpg';
import sweetImage from '../assets/images/menu_sweet_pastry_1795232891129.jpg';
import sandwichImage from '../assets/images/menu_sandwich_toastie_1795232891110.jpg';
import drinksImage from '../assets/images/menu_drinks_smoothie_1795232891725.jpg';

export const HERO_LATTE_IMAGE = heroLatte;
export const MENU_IMAGE_ASSETS = { brunch: brunchImage, sweet: sweetImage, sandwich: sandwichImage, drinks: drinksImage };

const IMG_BRUNCH = brunchImage;
const IMG_SWEET = sweetImage;
const IMG_SANDWICH = sandwichImage;
const IMG_DRINKS = drinksImage;

export const MENU_ITEMS: MenuItem[] = [
  // BRUNCH
  {
    id: 'sourdough-toast',
    group: 'menu',
    category: 'Brunch',
    name: 'Sourdough Toast',
    description: 'Two thick slices of organic country sourdough served with butter and house preserve.',
    dietary: 'GF available · Veg',
    allergens: 'Contains: Gluten, Milk',
    price: 4.0,
    imageSrc: IMG_BRUNCH,
  },
  {
    id: 'eggs-any-style',
    group: 'menu',
    category: 'Brunch',
    name: 'Eggs Any Style on Sourdough',
    description: 'Two free-range Cotswold eggs poached, fried, or scrambled on toasted sourdough.',
    dietary: 'GF available · Veg',
    allergens: 'Contains: Gluten, Eggs, Milk',
    price: 9.0,
    imageSrc: IMG_BRUNCH,
  },
  {
    id: 'cc-guac-sourdough',
    group: 'menu',
    category: 'Brunch',
    name: 'CC Guac on Sourdough',
    description: 'Smashed avocado with lime, chilli flakes, pickled shallots, and toasted seeds. Add poached eggs (+£3.00).',
    dietary: 'GF available · Vegan',
    allergens: 'Contains: Gluten, Sesame',
    price: 9.5,
    imageSrc: IMG_BRUNCH,
  },
  {
    id: 'eggs-benedict',
    group: 'menu',
    category: 'Brunch',
    name: 'Eggs Benedict',
    description: 'Smoked streaky bacon, two poached free-range eggs, and warm hollandaise on toasted sourdough.',
    dietary: 'GF available',
    allergens: 'Contains: Gluten, Eggs, Milk',
    price: 12.5,
    imageSrc: IMG_BRUNCH,
  },
  {
    id: 'eggs-royale',
    group: 'menu',
    category: 'Brunch',
    name: 'Eggs Royale',
    description: 'Scottish smoked salmon, two poached free-range eggs, chives, and golden hollandaise on sourdough.',
    dietary: 'GF available',
    allergens: 'Contains: Gluten, Eggs, Fish, Milk',
    price: 12.5,
    imageSrc: IMG_BRUNCH,
  },
  {
    id: 'turkish-eggs',
    group: 'menu',
    category: 'Brunch',
    name: 'Turkish Eggs',
    description: 'Garlic whipped yoghurt, two poached eggs, Aleppo chilli butter oil, dill, and warm sourdough.',
    dietary: 'Veg',
    allergens: 'Contains: Gluten, Eggs, Milk',
    price: 12.0,
    imageSrc: IMG_BRUNCH,
  },

  // SWEET
  {
    id: 'toasted-teacake',
    group: 'menu',
    category: 'Sweet',
    name: 'Toasted Teacake',
    description: 'Warm spiced fruit teacake served with cultured butter and strawberry jam.',
    dietary: 'Veg',
    allergens: 'Contains: Gluten, Milk',
    price: 4.5,
    imageSrc: IMG_SWEET,
  },
  {
    id: 'house-granola',
    group: 'menu',
    category: 'Sweet',
    name: 'House Granola',
    description: 'Toasted maple oats, Greek yoghurt, seasonal berry compote, and roasted almond butter.',
    dietary: 'Veg',
    allergens: 'Contains: Milk, Nuts, Oats',
    price: 8.0,
    imageSrc: IMG_SWEET,
  },
  {
    id: 'cardamom-knot',
    group: 'menu',
    category: 'Sweet',
    name: 'Swedish Cardamom Knot',
    description: 'Baked fresh every morning with freshly ground green cardamom and pearl sugar.',
    dietary: 'Veg',
    allergens: 'Contains: Gluten, Milk, Eggs',
    price: 4.25,
    imageSrc: IMG_SWEET,
  },
  {
    id: 'cinnamon-bun',
    group: 'menu',
    category: 'Sweet',
    name: 'Brown Butter Cinnamon Bun',
    description: 'Soft brioche spiral glazed with brown butter vanilla icing.',
    dietary: 'Veg',
    allergens: 'Contains: Gluten, Milk, Eggs',
    price: 4.5,
    imageSrc: IMG_SWEET,
  },

  // SANDWICHES
  {
    id: 'breakfast-bun',
    group: 'menu',
    category: 'Sandwiches',
    name: 'Breakfast Bun',
    description: 'Herbed sausage patty, fried free-range egg, aged cheddar, and smoky house relish on warm brioche.',
    allergens: 'Contains: Gluten, Eggs, Milk',
    price: 10.5,
    imageSrc: IMG_SANDWICH,
  },
  {
    id: 'three-cheese-toastie',
    group: 'menu',
    category: 'Sandwiches',
    name: 'Three-Cheese Sourdough Toastie',
    description: 'Westcombe cheddar, Gruyère, and mozzarella with caramelized red onion and Dijon mustard.',
    dietary: 'Veg',
    allergens: 'Contains: Gluten, Milk, Mustard',
    price: 9.5,
    imageSrc: IMG_SANDWICH,
  },
  {
    id: 'pesto-focaccia',
    group: 'menu',
    category: 'Sandwiches',
    name: 'Roast Chicken & Basil Pesto Focaccia',
    description: 'Slow-roasted chicken breast, basil pesto, rocket, and semi-dried tomatoes on olive oil focaccia.',
    allergens: 'Contains: Gluten, Nuts, Milk',
    price: 10.5,
    imageSrc: IMG_SANDWICH,
  },

  // SEASONAL
  {
    id: 'autumn-fig-tartine',
    group: 'menu',
    category: 'Seasonal',
    name: 'Whipped Ricotta & Black Fig Toast',
    description: 'Lemon zest ricotta, roasted black figs, thyme honey, and crushed pistachios on sourdough.',
    dietary: 'Veg · Limited Harvest',
    allergens: 'Contains: Gluten, Milk, Nuts',
    price: 11.0,
    imageSrc: IMG_BRUNCH,
  },
  {
    id: 'spiced-squash-melt',
    group: 'menu',
    category: 'Seasonal',
    name: 'Roasted Butternut & Sage Melt',
    description: 'Maple-roasted squash, crispy sage, melted taleggio, and chilli jam pressed on sourdough.',
    dietary: 'Veg · Seasonal Special',
    allergens: 'Contains: Gluten, Milk',
    price: 10.0,
    imageSrc: IMG_SANDWICH,
  },

  // DRINKS
  {
    id: 'flat-white',
    group: 'drinks',
    category: 'Drinks',
    name: 'Corner Club Flat White',
    description: 'Double ristretto of our seasonal Colombian & Ethiopian house blend with velvety steamed milk.',
    dietary: 'Oat / Coconut available',
    price: 3.8,
    imageSrc: HERO_LATTE_IMAGE,
  },
  {
    id: 'iced-matcha',
    group: 'drinks',
    category: 'Drinks',
    name: 'Iced Ceremonial Matcha',
    description: 'First-harvest Uji matcha hand-whisked over ice with creamy oat milk.',
    dietary: 'Vegan · GF',
    price: 4.6,
    imageSrc: IMG_DRINKS,
  },
  {
    id: 'berry-mango-smoothie',
    group: 'drinks',
    category: 'Drinks',
    name: 'Berry Mango Smoothie',
    description: 'Alphonso mango, wild blackberries, raspberries, mint, and fresh orange juice.',
    dietary: 'Vegan · GF',
    price: 5.5,
    imageSrc: IMG_DRINKS,
  },
  {
    id: 'spiced-chai-latte',
    group: 'drinks',
    category: 'Drinks',
    name: 'House Sticky Chai Latte',
    description: 'Slow-brewed whole cardamom, cinnamon, ginger, and Assam tea finished with honey.',
    dietary: 'GF · Veg',
    price: 4.4,
    imageSrc: HERO_LATTE_IMAGE,
  },
];

export const MENU_CATEGORIES: Array<'Brunch' | 'Sweet' | 'Sandwiches' | 'Seasonal' | 'Drinks'> = [
  'Brunch',
  'Sweet',
  'Sandwiches',
  'Seasonal',
  'Drinks',
];

export function formatPriceGbp(amount: number): string {
  return `£${amount.toFixed(2)}`;
}
