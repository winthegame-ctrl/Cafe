# CORNER CLUB — Café Hub

A mobile-first café customer hub built with React, TypeScript, Vite, Tailwind CSS, and Lucide icons.

## Run locally

Requirements: Node.js 20 or newer.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (normally `http://localhost:3000`).

## Production build

```bash
npm run build
npm run preview
```

## Current implementation notes

- Menu, loyalty pass, theme, Sudoku state, Wi-Fi confirmation state, and feedback entries are stored in this browser using local storage.
- The Wi-Fi screen gives connection instructions. A normal web app cannot force or verify the phone's Wi-Fi connection.
- Loyalty stamp updates and redemption require a secure café-side service or staff workflow. The customer-facing demo stamp button has been removed so customers cannot award themselves stamps.
- The Wallet screen is currently a visual pass preview, not a signed Apple Wallet / Google Wallet pass integration.
- Feedback and attached photos are saved locally in this browser. A backend endpoint is needed to deliver feedback to café staff.
- The Instagram profile link uses the `@cornerclublos` handle already shown in the project; verify that handle before publishing.

## Branding

Primary brand orange: `#F4511E`
Deep orange: `#E03406`

The existing café menu copy, menu prices, and supplied image assets have been preserved.
